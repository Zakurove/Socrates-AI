--
-- PostgreSQL database dump
--

\restrict 3mMS94yvCPvCBblZpS6DY21q81qiUOxSSx8JaLAy2meejjP07QYufr4n97uVg97

-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: collection_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.collection_role AS ENUM (
    'owner',
    'editor',
    'viewer'
);


--
-- Name: difficulty; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.difficulty AS ENUM (
    'beginner',
    'intermediate',
    'advanced'
);


--
-- Name: examiner_question_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.examiner_question_type AS ENUM (
    'free_text',
    'multiple_choice',
    'multi_select'
);


--
-- Name: item_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.item_status AS ENUM (
    'checked',
    'missed',
    'partial',
    'checked_after_time'
);


--
-- Name: mock_exam_practice_mode; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.mock_exam_practice_mode AS ENUM (
    'self_check',
    'ai_listen',
    'ai_conversation'
);


--
-- Name: mock_exam_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.mock_exam_status AS ENUM (
    'draft',
    'in_progress',
    'completed'
);


--
-- Name: report_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.report_status AS ENUM (
    'open',
    'reviewed_ok',
    'removed'
);


--
-- Name: report_target; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.report_target AS ENUM (
    'station',
    'collection',
    'user'
);


--
-- Name: session_mode; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.session_mode AS ENUM (
    'self_check',
    'ai_history',
    'ai_observer',
    'ai_communication'
);


--
-- Name: station_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.station_type AS ENUM (
    'history_taking',
    'physical_exam',
    'communication',
    'image_id',
    'custom',
    'qa',
    'equipment_id',
    'oral_qa'
);


--
-- Name: visibility; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.visibility AS ENUM (
    'private',
    'shared',
    'public'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_costs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_costs (
    id integer NOT NULL,
    session_id integer,
    user_id integer,
    model character varying(64) NOT NULL,
    tokens_in integer DEFAULT 0 NOT NULL,
    tokens_out integer DEFAULT 0 NOT NULL,
    cost_estimate_usd real DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: ai_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_costs_id_seq OWNED BY public.ai_costs.id;


--
-- Name: collection_invites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collection_invites (
    id integer NOT NULL,
    collection_id integer NOT NULL,
    email character varying(255) NOT NULL,
    role public.collection_role NOT NULL,
    token text NOT NULL,
    invited_by integer NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    accepted_at timestamp without time zone,
    accepted_by integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: collection_invites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.collection_invites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: collection_invites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.collection_invites_id_seq OWNED BY public.collection_invites.id;


--
-- Name: collection_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collection_members (
    id integer NOT NULL,
    collection_id integer NOT NULL,
    user_id integer NOT NULL,
    role public.collection_role NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: collection_members_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.collection_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: collection_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.collection_members_id_seq OWNED BY public.collection_members.id;


--
-- Name: collection_stars; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collection_stars (
    user_id integer NOT NULL,
    collection_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: collection_stations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collection_stations (
    id integer NOT NULL,
    collection_id integer NOT NULL,
    station_id integer NOT NULL,
    "order" integer DEFAULT 0 NOT NULL
);


--
-- Name: collection_stations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.collection_stations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: collection_stations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.collection_stations_id_seq OWNED BY public.collection_stations.id;


--
-- Name: collections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collections (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    specialty character varying(100),
    tags jsonb DEFAULT '[]'::jsonb,
    visibility public.visibility DEFAULT 'private'::public.visibility NOT NULL,
    published_at timestamp without time zone,
    star_count integer DEFAULT 0 NOT NULL,
    fork_count integer DEFAULT 0 NOT NULL,
    fork_of integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: collections_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.collections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: collections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.collections_id_seq OWNED BY public.collections.id;


--
-- Name: email_verifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_verifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    used_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: email_verifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_verifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_verifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_verifications_id_seq OWNED BY public.email_verifications.id;


--
-- Name: examiner_question_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.examiner_question_results (
    id integer NOT NULL,
    session_id integer NOT NULL,
    question_id integer NOT NULL,
    user_answer_transcript text,
    score real,
    feedback text
);


--
-- Name: examiner_question_results_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.examiner_question_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: examiner_question_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.examiner_question_results_id_seq OWNED BY public.examiner_question_results.id;


--
-- Name: examiner_questions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.examiner_questions (
    id integer NOT NULL,
    station_id integer NOT NULL,
    question text NOT NULL,
    question_type public.examiner_question_type DEFAULT 'free_text'::public.examiner_question_type NOT NULL,
    ideal_answer text,
    key_points jsonb DEFAULT '[]'::jsonb,
    config jsonb,
    image_url character varying(500),
    "order" integer DEFAULT 0 NOT NULL
);


--
-- Name: examiner_questions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.examiner_questions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: examiner_questions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.examiner_questions_id_seq OWNED BY public.examiner_questions.id;


--
-- Name: item_media; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.item_media (
    id integer NOT NULL,
    item_id integer NOT NULL,
    type text NOT NULL,
    url text NOT NULL,
    caption text,
    "order" integer DEFAULT 0 NOT NULL
);


--
-- Name: item_media_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.item_media_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: item_media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.item_media_id_seq OWNED BY public.item_media.id;


--
-- Name: item_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.item_results (
    id integer NOT NULL,
    session_id integer NOT NULL,
    item_id integer NOT NULL,
    status public.item_status NOT NULL,
    matched_transcript text,
    timestamp_seconds integer
);


--
-- Name: item_results_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.item_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: item_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.item_results_id_seq OWNED BY public.item_results.id;


--
-- Name: items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.items (
    id integer NOT NULL,
    section_id integer NOT NULL,
    parent_item_id integer,
    text text NOT NULL,
    is_critical boolean DEFAULT false NOT NULL,
    points integer DEFAULT 1 NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    explanation text,
    image_url text,
    image_caption text,
    video_url text
);


--
-- Name: items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.items_id_seq OWNED BY public.items.id;


--
-- Name: mock_exam_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mock_exam_attempts (
    id integer NOT NULL,
    mock_exam_id integer NOT NULL,
    user_id integer NOT NULL,
    attempt_number integer NOT NULL,
    current_station_index integer DEFAULT 0 NOT NULL,
    overall_score real,
    started_at timestamp without time zone DEFAULT now() NOT NULL,
    completed_at timestamp without time zone
);


--
-- Name: mock_exam_attempts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mock_exam_attempts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mock_exam_attempts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mock_exam_attempts_id_seq OWNED BY public.mock_exam_attempts.id;


--
-- Name: mock_exams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mock_exams (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title character varying(255) NOT NULL,
    station_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    rest_seconds integer DEFAULT 120 NOT NULL,
    practice_mode public.mock_exam_practice_mode DEFAULT 'self_check'::public.mock_exam_practice_mode NOT NULL,
    status public.mock_exam_status DEFAULT 'draft'::public.mock_exam_status NOT NULL,
    current_station_index integer DEFAULT 0 NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: mock_exams_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mock_exams_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mock_exams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mock_exams_id_seq OWNED BY public.mock_exams.id;


--
-- Name: password_resets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_resets (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    used_at timestamp without time zone,
    requested_ip character varying(64),
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: password_resets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.password_resets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: password_resets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.password_resets_id_seq OWNED BY public.password_resets.id;


--
-- Name: reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reports (
    id integer NOT NULL,
    target_type public.report_target NOT NULL,
    target_id integer NOT NULL,
    reporter_id integer,
    reason text NOT NULL,
    status public.report_status DEFAULT 'open'::public.report_status NOT NULL,
    reviewed_by integer,
    reviewed_at timestamp without time zone,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: reports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reports_id_seq OWNED BY public.reports.id;


--
-- Name: sections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sections (
    id integer NOT NULL,
    station_id integer NOT NULL,
    title character varying(255) NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    description text,
    image_url text,
    image_caption text
);


--
-- Name: sections_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sections_id_seq OWNED BY public.sections.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    station_id integer NOT NULL,
    mode public.session_mode DEFAULT 'self_check'::public.session_mode NOT NULL,
    time_limit_seconds integer NOT NULL,
    time_used_seconds integer,
    total_score real,
    critical_items_missed boolean DEFAULT false,
    transcript text,
    mock_exam_id integer,
    mock_exam_attempt_id integer,
    started_at timestamp without time zone DEFAULT now() NOT NULL,
    ended_at timestamp without time zone
);


--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: station_stars; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.station_stars (
    user_id integer NOT NULL,
    station_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: stations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stations (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title character varying(255) NOT NULL,
    type public.station_type DEFAULT 'custom'::public.station_type NOT NULL,
    default_time_minutes integer DEFAULT 7 NOT NULL,
    reading_time_minutes integer DEFAULT 1 NOT NULL,
    scenario text,
    patient_briefing text,
    has_patient_briefing boolean DEFAULT true NOT NULL,
    ai_patient_enabled boolean DEFAULT true NOT NULL,
    specialty character varying(100),
    difficulty public.difficulty,
    tags jsonb DEFAULT '[]'::jsonb,
    custom_vocabulary jsonb DEFAULT '[]'::jsonb,
    reference_image_url text,
    reference_image_caption text,
    fork_of integer,
    visibility public.visibility DEFAULT 'private'::public.visibility NOT NULL,
    published_at timestamp without time zone,
    star_count integer DEFAULT 0 NOT NULL,
    fork_count integer DEFAULT 0 NOT NULL,
    practice_count integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: stations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stations_id_seq OWNED BY public.stations.id;


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sessions (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password text NOT NULL,
    display_name character varying(100) NOT NULL,
    is_admin boolean DEFAULT false NOT NULL,
    bio text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    email_verified_at timestamp without time zone
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: ai_costs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_costs ALTER COLUMN id SET DEFAULT nextval('public.ai_costs_id_seq'::regclass);


--
-- Name: collection_invites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_invites ALTER COLUMN id SET DEFAULT nextval('public.collection_invites_id_seq'::regclass);


--
-- Name: collection_members id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_members ALTER COLUMN id SET DEFAULT nextval('public.collection_members_id_seq'::regclass);


--
-- Name: collection_stations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_stations ALTER COLUMN id SET DEFAULT nextval('public.collection_stations_id_seq'::regclass);


--
-- Name: collections id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections ALTER COLUMN id SET DEFAULT nextval('public.collections_id_seq'::regclass);


--
-- Name: email_verifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_verifications ALTER COLUMN id SET DEFAULT nextval('public.email_verifications_id_seq'::regclass);


--
-- Name: examiner_question_results id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.examiner_question_results ALTER COLUMN id SET DEFAULT nextval('public.examiner_question_results_id_seq'::regclass);


--
-- Name: examiner_questions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.examiner_questions ALTER COLUMN id SET DEFAULT nextval('public.examiner_questions_id_seq'::regclass);


--
-- Name: item_media id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_media ALTER COLUMN id SET DEFAULT nextval('public.item_media_id_seq'::regclass);


--
-- Name: item_results id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_results ALTER COLUMN id SET DEFAULT nextval('public.item_results_id_seq'::regclass);


--
-- Name: items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items ALTER COLUMN id SET DEFAULT nextval('public.items_id_seq'::regclass);


--
-- Name: mock_exam_attempts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mock_exam_attempts ALTER COLUMN id SET DEFAULT nextval('public.mock_exam_attempts_id_seq'::regclass);


--
-- Name: mock_exams id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mock_exams ALTER COLUMN id SET DEFAULT nextval('public.mock_exams_id_seq'::regclass);


--
-- Name: password_resets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_resets ALTER COLUMN id SET DEFAULT nextval('public.password_resets_id_seq'::regclass);


--
-- Name: reports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports ALTER COLUMN id SET DEFAULT nextval('public.reports_id_seq'::regclass);


--
-- Name: sections id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections ALTER COLUMN id SET DEFAULT nextval('public.sections_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: stations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stations ALTER COLUMN id SET DEFAULT nextval('public.stations_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: ai_costs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_costs (id, session_id, user_id, model, tokens_in, tokens_out, cost_estimate_usd, created_at) FROM stdin;
1	1	2	whisper-1	0	0	0	2026-05-09 18:19:24.549469
2	1	2	whisper-1	0	0	0	2026-05-09 18:19:33.876585
3	1	2	gpt-4o-mini	2972	1062	0.001083	2026-05-09 18:19:40.382389
4	1	2	whisper-1	0	0	0	2026-05-09 18:19:44.642222
5	1	2	whisper-1	0	0	0	2026-05-09 18:19:53.447224
6	1	2	gpt-4o-mini	3001	1060	0.00108615	2026-05-09 18:19:59.059587
7	1	2	whisper-1	0	0	0	2026-05-09 18:20:03.124205
8	1	2	whisper-1	0	0	0	2026-05-09 18:20:13.379014
9	1	2	whisper-1	0	0	0	2026-05-09 18:20:22.883867
10	1	2	whisper-1	0	0	0	2026-05-09 18:20:33.295434
11	1	2	gpt-4o-mini	3064	2196	0.0017772	2026-05-09 18:20:40.825489
12	1	2	whisper-1	0	0	0	2026-05-09 18:20:42.852254
13	1	2	gpt-4o-mini	3137	155	0.00056355	2026-05-09 18:20:46.99109
14	1	2	whisper-1	0	0	0	2026-05-09 18:20:55.046043
15	1	2	gpt-4o-mini	3158	170	0.0005757	2026-05-09 18:20:57.542821
16	1	2	whisper-1	0	0	0	2026-05-09 18:21:04.453306
17	1	2	gpt-4o-mini	3170	170	0.0005775	2026-05-09 18:21:07.279867
18	1	2	whisper-1	0	0	0	2026-05-09 18:21:12.717579
19	1	2	gpt-4o-mini	3185	247	0.00062595	2026-05-09 18:21:18.150485
20	1	2	whisper-1	0	0	0	2026-05-09 18:21:22.755614
21	1	2	whisper-1	0	0	0	2026-05-09 18:21:34.334489
22	1	2	whisper-1	0	0	0	2026-05-09 18:21:43.018683
23	1	2	whisper-1	0	0	0	2026-05-09 18:21:54.465528
24	1	2	whisper-1	0	0	0	2026-05-09 18:22:04.04571
25	1	2	whisper-1	0	0	0	2026-05-09 18:22:13.002351
26	1	2	whisper-1	0	0	0	2026-05-09 18:22:23.515594
27	1	2	whisper-1	0	0	0	2026-05-09 18:22:33.328323
28	1	2	whisper-1	0	0	0	2026-05-09 18:22:42.866582
29	1	2	whisper-1	0	0	0	2026-05-09 18:22:53.479546
30	1	2	whisper-1	0	0	0	2026-05-09 18:23:02.967337
31	1	2	whisper-1	0	0	0	2026-05-09 18:23:12.968535
32	1	2	whisper-1	0	0	0	2026-05-09 18:23:22.938759
33	1	2	whisper-1	0	0	0	2026-05-09 18:23:33.406539
34	1	2	whisper-1	0	0	0	2026-05-09 18:23:43.931407
35	1	2	whisper-1	0	0	0	2026-05-09 18:23:53.909853
36	1	2	whisper-1	0	0	0	2026-05-09 18:24:03.123498
37	1	2	whisper-1	0	0	0	2026-05-09 18:24:12.979019
38	1	2	whisper-1	0	0	0	2026-05-09 18:24:22.9246
39	1	2	whisper-1	0	0	0	2026-05-09 18:24:33.099352
40	1	2	whisper-1	0	0	0	2026-05-09 18:24:42.984129
41	1	2	whisper-1	0	0	0	2026-05-09 18:24:53.291733
42	1	2	whisper-1	0	0	0	2026-05-09 18:25:02.968189
43	1	2	whisper-1	0	0	0	2026-05-09 18:25:12.766961
44	1	2	whisper-1	0	0	0	2026-05-09 18:25:24.198581
45	1	2	whisper-1	0	0	0	2026-05-09 18:25:33.775585
46	1	2	whisper-1	0	0	0	2026-05-09 18:25:42.935608
47	1	2	whisper-1	0	0	0	2026-05-09 18:25:53.492764
48	1	2	whisper-1	0	0	0	2026-05-09 18:26:03.396103
49	1	2	whisper-1	0	0	0	2026-05-09 18:26:12.74526
50	1	2	whisper-1	0	0	0	2026-05-09 18:26:23.06267
51	1	2	whisper-1	0	0	0	2026-05-09 18:26:43.144883
52	1	2	gpt-4o-mini	3739	530	0.00087885	2026-05-09 18:26:49.288464
53	1	2	whisper-1	0	0	0	2026-05-09 18:26:52.749907
54	1	2	whisper-1	0	0	0	2026-05-09 18:27:03.71842
55	1	2	gpt-4o-mini	3747	1114	0.00123045	2026-05-09 18:27:05.695355
56	1	2	whisper-1	0	0	0	2026-05-09 18:27:12.924051
57	1	2	whisper-1	0	0	0	2026-05-09 18:27:23.595373
58	1	2	gpt-4o-mini	3786	1205	0.0012909	2026-05-09 18:27:24.62343
59	1	2	whisper-1	0	0	0	2026-05-09 18:27:32.741212
60	1	2	whisper-1	0	0	0	2026-05-09 18:27:44.435147
61	1	2	gpt-4o-mini	3821	1386	0.00140475	2026-05-09 18:27:46.383477
62	1	2	whisper-1	0	0	0	2026-05-09 18:27:53.413395
63	1	2	whisper-1	0	0	0	2026-05-09 18:28:02.834057
64	1	2	gpt-4o-mini	3866	1220	0.0013119	2026-05-09 18:28:05.559768
65	1	2	whisper-1	0	0	0	2026-05-09 18:28:14.247871
66	1	2	whisper-1	0	0	0	2026-05-09 18:28:24.281674
67	1	2	gpt-4o-mini	3890	980	0.0011715	2026-05-09 18:28:24.755637
68	1	2	whisper-1	0	0	0	2026-05-09 18:28:32.91592
69	1	2	whisper-1	0	0	0	2026-05-09 18:28:42.995452
70	1	2	whisper-1	0	0	0	2026-05-09 18:28:52.820008
71	1	2	whisper-1	0	0	0	2026-05-09 18:29:03.008908
72	1	2	whisper-1	0	0	0	2026-05-09 18:29:14.48962
73	1	2	whisper-1	0	0	0	2026-05-09 18:29:22.891425
74	1	2	whisper-1	0	0	0	2026-05-09 18:29:32.9606
75	1	2	whisper-1	0	0	0	2026-05-09 18:29:44.477124
76	1	2	whisper-1	0	0	0	2026-05-09 18:29:54.317097
77	1	2	whisper-1	0	0	0	2026-05-09 18:30:03.585038
78	1	2	whisper-1	0	0	0	2026-05-09 18:30:13.543247
79	1	2	whisper-1	0	0	0	2026-05-09 18:30:23.139775
80	1	2	whisper-1	0	0	0	2026-05-09 18:30:33.177514
81	1	2	whisper-1	0	0	0	2026-05-09 18:30:44.802668
82	1	2	whisper-1	0	0	0	2026-05-09 18:30:53.670481
83	\N	2	gemini-3.1-flash-live-preview	58	58	0.0001624	2026-05-09 18:31:24.563046
84	2	2	whisper-1	0	0	0	2026-05-09 18:54:16.207418
85	2	2	whisper-1	0	0	0	2026-05-09 18:54:27.072789
86	2	2	whisper-1	0	0	0	2026-05-09 18:54:35.314315
87	2	2	whisper-1	0	0	0	2026-05-09 18:54:49.069054
88	2	2	gpt-4o-mini	3285	1382	0.00132195	2026-05-09 18:54:49.668174
89	2	2	whisper-1	0	0	0	2026-05-09 18:54:55.873529
90	2	2	whisper-1	0	0	0	2026-05-09 18:55:06.264232
91	2	2	whisper-1	0	0	0	2026-05-09 18:55:15.184329
92	2	2	whisper-1	0	0	0	2026-05-09 18:55:25.780667
93	2	2	gpt-4o-mini	3387	1382	0.00133725	2026-05-09 18:55:27.046488
94	2	2	whisper-1	0	0	0	2026-05-09 18:55:37.66876
95	2	2	whisper-1	0	0	0	2026-05-09 18:55:45.50855
96	2	2	whisper-1	0	0	0	2026-05-09 18:55:54.634745
97	2	2	whisper-1	0	0	0	2026-05-09 18:56:04.547829
98	2	2	gpt-4o-mini	3487	1382	0.00135225	2026-05-09 18:56:08.897244
99	2	2	whisper-1	0	0	0	2026-05-09 18:56:15.152942
100	2	2	whisper-1	0	0	0	2026-05-09 18:56:25.133847
101	2	2	whisper-1	0	0	0	2026-05-09 18:56:35.139378
102	2	2	whisper-1	0	0	0	2026-05-09 18:56:44.974577
103	2	2	gpt-4o-mini	3524	1382	0.0013578	2026-05-09 18:56:48.653923
104	2	2	whisper-1	0	0	0	2026-05-09 18:56:55.87172
105	2	2	whisper-1	0	0	0	2026-05-09 18:57:04.704737
106	2	2	whisper-1	0	0	0	2026-05-09 18:57:15.106336
107	2	2	whisper-1	0	0	0	2026-05-09 18:57:24.736702
108	2	2	gpt-4o-mini	3596	1382	0.0013686	2026-05-09 18:57:34.417737
109	2	2	whisper-1	0	0	0	2026-05-09 18:57:35.047132
110	2	2	whisper-1	0	0	0	2026-05-09 18:57:44.739744
111	2	2	whisper-1	0	0	0	2026-05-09 18:57:55.995673
112	2	2	whisper-1	0	0	0	2026-05-09 18:58:05.103691
113	2	2	gpt-4o-mini	3643	1382	0.00137565	2026-05-09 18:58:05.565004
114	2	2	whisper-1	0	0	0	2026-05-09 18:58:14.719313
115	2	2	whisper-1	0	0	0	2026-05-09 18:58:25.975836
116	2	2	whisper-1	0	0	0	2026-05-09 18:58:34.902267
117	2	2	whisper-1	0	0	0	2026-05-09 18:58:45.241015
118	2	2	whisper-1	0	0	0	2026-05-09 18:58:56.239208
119	2	2	whisper-1	0	0	0	2026-05-09 18:59:05.386502
120	2	2	whisper-1	0	0	0	2026-05-09 18:59:14.837463
121	2	2	whisper-1	0	0	0	2026-05-09 18:59:25.424879
122	2	2	whisper-1	0	0	0	2026-05-09 18:59:34.94122
123	2	2	whisper-1	0	0	0	2026-05-09 18:59:45.058988
124	3	2	whisper-1	0	0	0	2026-05-09 19:04:45.985101
125	3	2	gpt-4o-mini	3264	1382	0.0013188	2026-05-09 19:05:35.216021
126	4	2	whisper-1	0	0	0	2026-05-09 19:09:10.897449
127	4	2	whisper-1	0	0	0	2026-05-09 19:09:21.785283
128	4	2	whisper-1	0	0	0	2026-05-09 19:09:31.16793
129	4	2	whisper-1	0	0	0	2026-05-09 19:09:40.862369
130	4	2	whisper-1	0	0	0	2026-05-09 19:09:52.382347
131	4	2	whisper-1	0	0	0	2026-05-09 19:10:01.476822
132	4	2	gpt-4o-mini	3265	1382	0.00131895	2026-05-09 19:10:02.523689
133	4	2	whisper-1	0	0	0	2026-05-09 19:10:11.612085
134	4	2	whisper-1	0	0	0	2026-05-09 19:10:23.243852
135	4	2	whisper-1	0	0	0	2026-05-09 19:10:34.296829
136	4	2	whisper-1	0	0	0	2026-05-09 19:10:40.821667
137	4	2	gpt-4o-mini	3404	1382	0.0013398	2026-05-09 19:10:47.485121
138	4	2	whisper-1	0	0	0	2026-05-09 19:10:50.951953
139	4	2	whisper-1	0	0	0	2026-05-09 19:11:01.93294
140	4	2	whisper-1	0	0	0	2026-05-09 19:11:10.939367
141	4	2	whisper-1	0	0	0	2026-05-09 19:11:21.721386
142	4	2	gpt-4o-mini	3445	1382	0.00134595	2026-05-09 19:11:27.948022
143	4	2	whisper-1	0	0	0	2026-05-09 19:11:31.361877
144	4	2	whisper-1	0	0	0	2026-05-09 19:11:42.654164
145	4	2	whisper-1	0	0	0	2026-05-09 19:11:54.982187
146	4	2	whisper-1	0	0	0	2026-05-09 19:12:01.89709
147	4	2	gpt-4o-mini	3545	1382	0.00136095	2026-05-09 19:12:05.267922
148	4	2	whisper-1	0	0	0	2026-05-09 19:12:10.851906
149	4	2	whisper-1	0	0	0	2026-05-09 19:12:25.671376
150	4	2	whisper-1	0	0	0	2026-05-09 19:12:31.298137
151	4	2	gpt-4o-mini	3596	1382	0.0013686	2026-05-09 19:12:40.639045
152	4	2	whisper-1	0	0	0	2026-05-09 19:12:42.257617
153	4	2	whisper-1	0	0	0	2026-05-09 19:12:51.057462
154	4	2	whisper-1	0	0	0	2026-05-09 19:13:02.716671
155	4	2	gpt-4o-mini	3617	1382	0.00137175	2026-05-09 19:13:05.63546
156	4	2	whisper-1	0	0	0	2026-05-09 19:13:12.778352
157	4	2	whisper-1	0	0	0	2026-05-09 19:13:22.211937
158	4	2	whisper-1	0	0	0	2026-05-09 19:13:32.449722
159	4	2	whisper-1	0	0	0	2026-05-09 19:13:41.139762
160	4	2	whisper-1	0	0	0	2026-05-09 19:13:51.04192
161	4	2	whisper-1	0	0	0	2026-05-09 19:14:01.084286
162	4	2	whisper-1	0	0	0	2026-05-09 19:14:10.929618
163	4	2	whisper-1	0	0	0	2026-05-09 19:14:22.001085
164	4	2	whisper-1	0	0	0	2026-05-09 19:14:30.816449
165	4	2	whisper-1	0	0	0	2026-05-09 19:14:41.565061
166	4	2	whisper-1	0	0	0	2026-05-09 19:14:52.234082
167	4	2	whisper-1	0	0	0	2026-05-09 19:15:01.341782
168	4	2	gpt-4o-mini	3834	1382	0.0014043	2026-05-09 19:15:04.541045
169	4	2	whisper-1	0	0	0	2026-05-09 19:15:10.915344
170	4	2	whisper-1	0	0	0	2026-05-09 19:15:21.41347
171	4	2	whisper-1	0	0	0	2026-05-09 19:15:31.998828
172	4	2	gpt-4o-mini	3881	1382	0.00141135	2026-05-09 19:15:34.779194
173	5	2	whisper-1	0	0	0	2026-05-09 19:16:14.923191
174	5	2	gpt-4o-mini	3269	32	0.00050955	2026-05-09 19:16:16.18315
175	5	2	whisper-1	0	0	0	2026-05-09 19:16:26.326156
176	5	2	gpt-4o-mini	3292	63	0.0005316	2026-05-09 19:16:28.281859
177	5	2	whisper-1	0	0	0	2026-05-09 19:16:34.573672
178	5	2	gpt-4o-mini	3323	40	0.00052245	2026-05-09 19:16:36.063657
179	5	2	whisper-1	0	0	0	2026-05-09 19:16:44.821934
180	5	2	gpt-4o-mini	3351	214	0.00063105	2026-05-09 19:16:50.857106
181	5	2	whisper-1	0	0	0	2026-05-09 19:16:54.785562
182	5	2	gpt-4o-mini	3379	215	0.00063585	2026-05-09 19:17:01.607527
183	5	2	whisper-1	0	0	0	2026-05-09 19:17:04.492726
184	5	2	gpt-4o-mini	3395	295	0.00068625	2026-05-09 19:17:11.918333
185	5	2	whisper-1	0	0	0	2026-05-09 19:17:14.597015
186	5	2	gpt-4o-mini	3414	304	0.0006945	2026-05-09 19:17:22.490389
187	5	2	whisper-1	0	0	0	2026-05-09 19:17:24.925199
188	5	2	gpt-4o-mini	3435	300	0.00069525	2026-05-09 19:17:31.121855
189	5	2	whisper-1	0	0	0	2026-05-09 19:17:34.63016
190	5	2	whisper-1	0	0	0	2026-05-09 19:17:44.503838
191	5	2	whisper-1	0	0	0	2026-05-09 19:17:55.489313
192	5	2	whisper-1	0	0	0	2026-05-09 19:18:05.919398
193	5	2	whisper-1	0	0	0	2026-05-09 19:18:14.527815
194	5	2	whisper-1	0	0	0	2026-05-09 19:18:24.428344
195	5	2	whisper-1	0	0	0	2026-05-09 19:18:35.180751
196	5	2	whisper-1	0	0	0	2026-05-09 19:18:44.848016
197	5	2	whisper-1	0	0	0	2026-05-09 19:18:54.568326
198	5	2	whisper-1	0	0	0	2026-05-09 19:19:05.519418
199	5	2	whisper-1	0	0	0	2026-05-09 19:19:14.842603
200	5	2	whisper-1	0	0	0	2026-05-09 19:19:24.863565
201	5	2	whisper-1	0	0	0	2026-05-09 19:19:35.80041
202	5	2	whisper-1	0	0	0	2026-05-09 19:19:45.962035
203	5	2	whisper-1	0	0	0	2026-05-09 19:19:55.171978
204	5	2	whisper-1	0	0	0	2026-05-09 19:20:04.545522
205	5	2	whisper-1	0	0	0	2026-05-09 19:20:14.459614
206	5	2	whisper-1	0	0	0	2026-05-09 19:20:25.867896
207	5	2	whisper-1	0	0	0	2026-05-09 19:20:34.539995
208	5	2	whisper-1	0	0	0	2026-05-09 19:20:45.16055
209	5	2	whisper-1	0	0	0	2026-05-09 19:20:55.037586
210	5	2	whisper-1	0	0	0	2026-05-09 19:21:05.120936
211	5	2	whisper-1	0	0	0	2026-05-09 19:21:15.162563
212	5	2	whisper-1	0	0	0	2026-05-09 19:21:24.526246
213	5	2	whisper-1	0	0	0	2026-05-09 19:21:35.481808
214	5	2	whisper-1	0	0	0	2026-05-09 19:21:44.462569
215	5	2	whisper-1	0	0	0	2026-05-09 19:21:55.152698
216	5	2	whisper-1	0	0	0	2026-05-09 19:22:04.573674
217	5	2	whisper-1	0	0	0	2026-05-09 19:22:14.560407
218	5	2	whisper-1	0	0	0	2026-05-09 19:22:25.143495
219	5	2	whisper-1	0	0	0	2026-05-09 19:22:35.117898
220	5	2	whisper-1	0	0	0	2026-05-09 19:22:44.280191
221	5	2	whisper-1	0	0	0	2026-05-09 19:22:55.111356
222	5	2	whisper-1	0	0	0	2026-05-09 19:23:06.199341
223	5	2	whisper-1	0	0	0	2026-05-09 19:23:15.061273
224	5	2	whisper-1	0	0	0	2026-05-09 19:23:24.599486
225	5	2	whisper-1	0	0	0	2026-05-09 19:23:34.710799
226	5	2	whisper-1	0	0	0	2026-05-09 19:23:46.303908
227	5	2	whisper-1	0	0	0	2026-05-09 19:23:54.72223
228	5	2	whisper-1	0	0	0	2026-05-09 19:24:04.454293
229	5	2	whisper-1	0	0	0	2026-05-09 19:24:15.018414
230	5	2	whisper-1	0	0	0	2026-05-09 19:24:24.764141
231	5	2	whisper-1	0	0	0	2026-05-09 19:24:35.019358
232	5	2	whisper-1	0	0	0	2026-05-09 19:24:45.29935
233	5	2	whisper-1	0	0	0	2026-05-09 19:24:54.939545
234	5	2	whisper-1	0	0	0	2026-05-09 19:25:04.616702
235	\N	2	gemini-3.1-flash-live-preview	13	13	3.64e-05	2026-05-09 19:25:33.034935
236	\N	2	gemini-3.1-flash-live-preview	46	46	0.0001288	2026-05-09 19:47:42.199825
237	7	2	whisper-1	0	0	0	2026-05-10 21:32:26.641937
238	7	2	whisper-1	0	0	0	2026-05-10 21:32:36.424807
239	7	2	gpt-4o-mini	2761	940	0.00097815	2026-05-10 21:32:39.017949
240	7	2	whisper-1	0	0	0	2026-05-10 21:32:44.781898
241	7	2	gpt-4o-mini	2780	940	0.000981	2026-05-10 21:32:54.704718
242	7	2	whisper-1	0	0	0	2026-05-10 21:32:57.048113
243	7	2	gpt-4o-mini	2781	940	0.00098115	2026-05-10 21:33:10.217101
244	7	2	gpt-4o-mini	2208	940	0.0008952	2026-05-10 21:33:13.459864
245	8	2	whisper-1	0	0	0	2026-05-10 21:50:25.564051
246	8	2	whisper-1	0	0	0	2026-05-10 21:50:34.517189
247	8	2	gpt-4o-mini	2781	958	0.00099195	2026-05-10 21:50:35.718072
248	8	2	whisper-1	0	0	0	2026-05-10 21:50:45.178477
249	8	2	gpt-4o-mini	2837	212	0.00055275	2026-05-10 21:50:47.697266
250	8	2	whisper-1	0	0	0	2026-05-10 21:50:54.803308
251	8	2	gpt-4o-mini	2869	140	0.00051435	2026-05-10 21:50:56.472186
252	8	2	whisper-1	0	0	0	2026-05-10 21:51:04.340748
253	8	2	gpt-4o-mini	2889	331	0.00063195	2026-05-10 21:51:09.914537
254	8	2	whisper-1	0	0	0	2026-05-10 21:51:14.150536
255	8	2	gpt-4o-mini	2914	368	0.0006579	2026-05-10 21:51:18.238097
256	8	2	whisper-1	0	0	0	2026-05-10 21:51:25.691836
257	8	2	gpt-4o-mini	2932	354	0.0006522	2026-05-10 21:51:30.449405
258	8	2	whisper-1	0	0	0	2026-05-10 21:51:33.847142
259	8	2	gpt-4o-mini	2947	504	0.00074445	2026-05-10 21:51:40.627726
260	8	2	whisper-1	0	0	0	2026-05-10 21:51:44.063394
261	8	2	gpt-4o-mini	2962	686	0.0008559	2026-05-10 21:51:51.254816
262	8	2	whisper-1	0	0	0	2026-05-10 21:51:54.048707
263	8	2	gpt-4o-mini	2984	417	0.0006978	2026-05-10 21:51:58.227964
264	8	2	whisper-1	0	0	0	2026-05-10 21:52:04.433131
265	8	2	gpt-4o-mini	3006	765	0.0009099	2026-05-10 21:52:12.850091
266	8	2	whisper-1	0	0	0	2026-05-10 21:52:14.832814
267	8	2	gpt-4o-mini	3039	512	0.00076305	2026-05-10 21:52:21.201077
268	8	2	whisper-1	0	0	0	2026-05-10 21:52:25.673737
269	8	2	whisper-1	0	0	0	2026-05-10 21:52:34.834924
270	8	2	gpt-4o-mini	3062	868	0.0009801	2026-05-10 21:52:34.94735
271	8	2	whisper-1	0	0	0	2026-05-10 21:52:44.604263
272	8	2	whisper-1	0	0	0	2026-05-10 21:52:54.605497
273	8	2	gpt-4o-mini	3109	658	0.00086115	2026-05-10 21:52:54.665264
274	8	2	whisper-1	0	0	0	2026-05-10 21:53:04.725993
275	8	2	whisper-1	0	0	0	2026-05-10 21:53:14.152065
276	8	2	gpt-4o-mini	3154	1172	0.0011763	2026-05-10 21:53:21.303361
277	8	2	whisper-1	0	0	0	2026-05-10 21:53:24.08005
278	8	2	gpt-4o-mini	3185	799	0.00095715	2026-05-10 21:53:32.825216
279	8	2	whisper-1	0	0	0	2026-05-10 21:53:34.37133
280	8	2	gpt-4o-mini	3211	1000	0.00108165	2026-05-10 21:53:45.192072
281	8	2	whisper-1	0	0	0	2026-05-10 21:53:45.453486
282	8	2	whisper-1	0	0	0	2026-05-10 21:53:54.619258
283	8	2	gpt-4o-mini	3242	857	0.0010005	2026-05-10 21:53:54.819333
284	8	2	whisper-1	0	0	0	2026-05-10 21:54:04.877509
285	8	2	whisper-1	0	0	0	2026-05-10 21:54:14.06351
286	8	2	gpt-4o-mini	3289	1351	0.00130395	2026-05-10 21:54:18.917541
287	8	2	whisper-1	0	0	0	2026-05-10 21:54:24.650957
288	8	2	whisper-1	0	0	0	2026-05-10 21:54:35.252169
289	8	2	gpt-4o-mini	3330	1440	0.0013635	2026-05-10 21:54:39.486048
290	8	2	whisper-1	0	0	0	2026-05-10 21:54:44.428462
291	8	2	whisper-1	0	0	0	2026-05-10 21:54:54.34021
292	8	2	gpt-4o-mini	3367	1559	0.00144045	2026-05-10 21:54:58.896611
293	8	2	whisper-1	0	0	0	2026-05-10 21:55:04.767582
294	8	2	gpt-4o-mini	3409	1007	0.00111555	2026-05-10 21:55:14.65662
295	8	2	whisper-1	0	0	0	2026-05-10 21:55:15.375356
296	8	2	whisper-1	0	0	0	2026-05-10 21:55:23.913654
297	8	2	gpt-4o-mini	3433	898	0.00105375	2026-05-10 21:55:24.579272
298	8	2	whisper-1	0	0	0	2026-05-10 21:55:34.552434
299	8	2	whisper-1	0	0	0	2026-05-10 21:55:44.629967
300	8	2	gpt-4o-mini	3468	1676	0.0015258	2026-05-10 21:55:52.229769
301	8	2	whisper-1	0	0	0	2026-05-10 21:55:54.16414
302	8	2	whisper-1	0	0	0	2026-05-10 21:56:04.079168
303	8	2	gpt-4o-mini	3513	1271	0.00128955	2026-05-10 21:56:07.945686
304	8	2	whisper-1	0	0	0	2026-05-10 21:56:14.156448
305	8	2	whisper-1	0	0	0	2026-05-10 21:56:24.028932
306	8	2	gpt-4o-mini	3551	1176	0.00123825	2026-05-10 21:56:26.035296
307	8	2	gpt-4o-mini	2997	217	0.00057975	2026-05-10 21:56:30.949506
\.


--
-- Data for Name: collection_invites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collection_invites (id, collection_id, email, role, token, invited_by, expires_at, accepted_at, accepted_by, created_at) FROM stdin;
\.


--
-- Data for Name: collection_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collection_members (id, collection_id, user_id, role, created_at) FROM stdin;
1	1	2	owner	2026-05-10 21:01:58.687776
\.


--
-- Data for Name: collection_stars; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collection_stars (user_id, collection_id, created_at) FROM stdin;
\.


--
-- Data for Name: collection_stations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collection_stations (id, collection_id, station_id, "order") FROM stdin;
1	1	5	0
2	1	4	0
\.


--
-- Data for Name: collections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collections (id, user_id, title, description, specialty, tags, visibility, published_at, star_count, fork_count, fork_of, created_at, updated_at) FROM stdin;
1	2	NGHA PMR	\N	\N	[]	private	\N	0	0	\N	2026-05-10 21:01:58.684182	2026-05-10 21:01:58.684182
\.


--
-- Data for Name: email_verifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_verifications (id, user_id, token, expires_at, used_at, created_at) FROM stdin;
1	1	e8ce68b77715c9b7baec55605df689916080b788058443ffd74051cd3a6ca1f9	2026-05-07 15:51:36.15	\N	2026-05-06 15:51:36.152053
2	2	4d72f1393a40d50fb22972c52bd8de1c4274ac8c9752e65127ce884c8512eb38	2026-05-10 14:37:57.036	2026-05-09 14:39:12.202	2026-05-09 14:37:57.037165
\.


--
-- Data for Name: examiner_question_results; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.examiner_question_results (id, session_id, question_id, user_answer_transcript, score, feedback) FROM stdin;
\.


--
-- Data for Name: examiner_questions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.examiner_questions (id, station_id, question, question_type, ideal_answer, key_points, config, image_url, "order") FROM stdin;
1	2	What is your top differential and why?	free_text	Migraine with aura. The patient describes stereotyped, episodic, unilateral throbbing headaches lasting one to two days, associated with nausea, photophobia, and phonophobia, preceded by a fully reversible visual aura of shimmering zigzag lines. She has a long personal history of similar milder attacks, a positive family history in her mother, and classic triggers of poor sleep and stress. She has no red flag features: no thunderclap onset, no focal deficit, no fever or meningism, no progressive pattern, and she is under 50.	["Names migraine with aura as the top differential", "Justifies using positive features (unilateral throbbing, aura, photophobia, phonophobia, episodic stereotyped attacks)", "Notes supportive history (family history of migraine, longstanding similar episodes, typical triggers)", "Explicitly rules out red flags for secondary headache"]	\N	\N	0
2	2	List three red flags for secondary headache that you would worry about.	free_text	Any three of: sudden thunderclap onset (subarachnoid hemorrhage), new focal neurological deficit that does not resolve (stroke, space-occupying lesion), fever with neck stiffness and photophobia (meningitis), new-onset headache after age 50 (giant cell arteritis, malignancy), progressive headache worse on waking or with cough / valsalva (raised intracranial pressure), headache following recent head trauma (subdural hematoma), or systemic features such as weight loss, night sweats, or known immunocompromise.	["Thunderclap / sudden onset", "Focal neurological deficit or altered consciousness", "Fever with meningism", "New-onset headache over 50", "Progressive / positional / precipitated by valsalva", "Recent head trauma"]	\N	\N	1
3	2	What first-line investigations would you consider if you suspected subarachnoid hemorrhage?	free_text	Urgent non-contrast CT head within six hours of symptom onset — sensitivity approaches 100% at this window. If the CT is negative and clinical suspicion remains, proceed to lumbar puncture at least 12 hours after headache onset, looking for xanthochromia in the CSF supernatant. Baseline bloods should include full blood count, urea and electrolytes, coagulation screen, group and save, and a blood glucose. CT angiography is used to identify the aneurysm once subarachnoid hemorrhage is confirmed.	["Urgent non-contrast CT head (ideally within 6 hours)", "Lumbar puncture at least 12 hours post-onset if CT negative, looking for xanthochromia", "Basic bloods: FBC, U&E, coagulation, group and save, glucose", "CT angiography to localise the aneurysm once confirmed"]	\N	\N	2
4	2	What first-line acute treatment would you offer this patient?	free_text	For an acute migraine attack: a triptan such as sumatriptan, combined with a simple analgesic such as ibuprofen or aspirin, and an antiemetic such as metoclopramide or prochlorperazine, which also has an anti-migraine effect. Advise her to rest in a quiet, dark room. Safety-net with red flag advice and arrange follow-up. Importantly, because she has migraine with aura, the combined oral contraceptive pill should be stopped and an alternative form of contraception arranged, as it increases her ischemic stroke risk.	["Triptan (e.g., sumatriptan)", "Simple analgesic (NSAID or aspirin)", "Antiemetic (metoclopramide or prochlorperazine)", "Conservative measures: rest in a dark quiet room", "Stop combined oral contraceptive — contraindicated in migraine with aura", "Safety-net and arrange follow-up"]	\N	\N	3
5	2	When would you refer urgently to neurology?	free_text	Refer urgently or admit if there are red flag features: thunderclap onset, persistent focal neurological deficit, reduced level of consciousness, meningism, new-onset headache over 50, progressive headache, headache worse on waking or with valsalva, headache in pregnancy or the postpartum period, headache in an immunocompromised patient, or a significant change in the pattern of a pre-existing headache disorder. Routine neurology referral is appropriate for poorly controlled chronic migraine not responding to standard preventive therapy, for suspected cluster headache for specialist confirmation and preventive management, and for suspected medication-overuse headache where outpatient withdrawal support is needed.	["Any red flag (thunderclap, focal deficit, meningism, progressive, new over 50)", "Headache in pregnancy / postpartum or immunocompromise", "Significant change from established headache pattern", "Chronic migraine unresponsive to first-line prevention", "Suspected cluster headache", "Medication-overuse headache needing withdrawal support"]	\N	\N	4
28	4	Give three differential diagnoses for this patient	free_text	Mention any 3 of the following:\n- Impingement\n- Rotator cuff pathology\n- AC joint pathology\n- Biceps tendonitis \n- Frozen shoulder	[]	\N	\N	0
\.


--
-- Data for Name: item_media; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.item_media (id, item_id, type, url, caption, "order") FROM stdin;
4111	22776	image	/uploads/items/e589197f-0cc3-4c9c-be8d-a1ed50a858e3.png	\N	0
4112	22786	image	/uploads/items/430a579d-dee1-4f67-84a8-5fd1c165ce36.png	\N	0
4113	22796	image	/uploads/items/a9a67cc6-da86-4d8c-8a71-da30d8b5b72a.png	\N	0
4114	22797	image	/uploads/items/7b87c0e0-2f13-49a9-a090-b382dbaa8a0d.png	\N	0
4115	22798	image	/uploads/items/6d4d2396-2c37-49db-a26a-dafc8e478110.png	\N	0
4116	22799	image	/uploads/items/e5ce65c2-9e95-4f7c-bceb-880ae248fae6.png	\N	0
4117	22800	image	/uploads/items/d6156775-d9f6-4165-8319-3462108e7cd3.png	\N	0
4118	22801	image	/uploads/items/1f8db6d9-dab3-4d63-97e7-fc646a45e7cf.png	\N	0
11	381	image	/uploads/items/f0c36f73-3509-4ad6-a89d-4bbe11d2b523.png	Step-off deformity	0
12	383	video	https://www.youtube.com/watch?v=YPx69wCMt-w	\N	0
13	388	image	/uploads/items/e69fe5c1-d13f-4e36-8f58-257722041898.jpg	\N	0
3591	18070	image	/uploads/items/f0c36f73-3509-4ad6-a89d-4bbe11d2b523.png	Step-off deformity	0
3592	18072	video	https://www.youtube.com/watch?v=6Z_9lfX_Pc8	\N	0
3593	18077	image	/uploads/items/e69fe5c1-d13f-4e36-8f58-257722041898.jpg	\N	0
3594	18092	image	/uploads/items/841151c8-9aa0-4a96-a952-8e0e6f894c7c.png	\N	0
3595	18092	image	/uploads/items/cef85ca6-e936-453c-b3da-5ae45dfab37c.png	\N	1
3596	18117	image	/uploads/items/a2d68f49-4954-4aa8-842e-97b438400b0b.png	\N	0
3597	18117	video	https://www.youtube.com/watch?v=k21FNtBjQ14	\N	1
3598	18118	image	/uploads/items/c5ce18b7-a95b-4608-b24e-6a50f21b414c.png	\N	0
3599	18118	video	https://youtu.be/6GkKB2oXi3o?si=4OtDSglTZSe_SSVW&t=36	\N	1
3600	18119	image	/uploads/items/1ef3e4ca-2d65-46a9-901b-cbb6f26b493a.png	\N	0
3601	18121	image	/uploads/items/56f505c8-0bc5-4dcd-a7a7-42934879e909.png	\N	0
3602	18122	image	/uploads/items/93329d1b-fa65-4885-9574-dd203b0ae305.png	\N	0
3603	18123	image	/uploads/items/1905bd47-2f4e-43d8-aeb6-6d238b32b772.png	\N	0
3604	18124	image	/uploads/items/db810b7a-bd5d-4332-8692-05bde675a847.png	\N	0
3605	18126	image	/uploads/items/250b2792-c8d0-4f1e-87d0-ca31a42fa41f.png	\N	0
3606	18129	image	/uploads/items/60056206-8535-4dec-b9ff-382f953f5c8a.png	\N	0
3607	18130	image	/uploads/items/e7aa7b68-a649-4c53-86ed-18b6ef68a3d1.png	\N	0
3608	18132	image	/uploads/items/67c80ba2-2666-495c-9d3a-758bc9b5eb04.png	\N	0
3609	18134	image	/uploads/items/486dc958-0ae0-4041-89cc-b3ffa4d5ed16.png	\N	0
3610	18136	image	/uploads/items/f87d11bf-819e-4da9-b2c0-76bbf34eac02.png	\N	0
3611	18137	video	https://www.youtube.com/watch?v=JMKwNRLHIvY	\N	0
3612	18137	image	/uploads/items/4dea819f-88bb-4fda-82ed-f73ba01c10f3.png	\N	1
3613	18139	image	/uploads/items/42eb6e3e-1ba1-406c-b41f-00862ac4d6d5.png	\N	0
3614	18139	video	https://youtu.be/-7346RaEGKU?si=HP-YL5wmA-8bNNl4&t=46	\N	1
3615	18140	image	/uploads/items/b45a23f0-821a-4cc1-ad9d-62e0d8ab4dec.png	\N	0
3616	18141	image	/uploads/items/3d233152-f2d7-4e87-9d85-4fcd4076526a.png	\N	0
3617	18149	image	/uploads/items/d8f13697-d14b-4aea-bbc5-729d2dd78baf.png	\N	0
\.


--
-- Data for Name: item_results; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.item_results (id, session_id, item_id, status, matched_transcript, timestamp_seconds) FROM stdin;
773	8	22753	checked	...this is Dr. Nasser Al Harbi, I'm a physiatry resident. i would be washing my hands...	\N
774	8	22754	checked	...this is Dr. Nasser Al Harbi, I'm a physiatry resident.	\N
775	8	22755	checked	...may I confirm your name and age please...would that be okay with you?	\N
776	8	22756	checked	...the examination would include me touching and moving your upper limbs...please just remove your shirt...	\N
777	8	22757	checked	...I will be on the right side of the patient.	\N
778	8	22758	checked	\N	\N
779	8	22759	checked	...I will look for any asymmetry in the upper limbs...	\N
780	8	22760	checked	\N	\N
781	8	22761	checked	\N	\N
782	8	22762	checked	\N	\N
783	8	22763	checked	\N	\N
784	8	22764	checked	\N	\N
785	8	22765	checked	\N	\N
786	8	22766	checked	\N	\N
787	8	22767	checked	\N	\N
788	8	22768	checked	\N	\N
789	8	22769	checked	\N	\N
790	8	22770	checked	\N	\N
791	8	22771	checked	\N	\N
792	8	22772	checked	\N	\N
793	8	22773	checked	\N	\N
794	8	22774	checked	\N	\N
795	8	22775	checked	\N	\N
796	8	22776	checked	\N	\N
797	8	22777	checked	\N	\N
798	8	22778	checked	\N	\N
799	8	22779	checked	\N	\N
800	8	22780	checked	\N	\N
801	8	22781	checked	\N	\N
802	8	22782	checked	\N	\N
803	8	22783	checked	\N	\N
804	8	22784	checked	\N	\N
805	8	22785	checked	\N	\N
806	8	22786	checked	\N	\N
807	8	22787	checked	\N	\N
808	8	22788	checked	\N	\N
809	8	22789	checked	\N	\N
810	8	22790	checked	\N	\N
811	8	22791	checked	\N	\N
812	8	22792	checked	\N	\N
813	8	22793	checked	\N	\N
814	8	22794	checked	\N	\N
815	8	22795	checked	\N	\N
816	8	22796	checked	\N	\N
817	8	22797	checked	\N	\N
818	8	22798	checked	\N	\N
819	8	22799	checked	\N	\N
820	8	22800	checked	\N	\N
821	8	22801	checked	\N	\N
822	8	22802	checked	\N	\N
823	8	22803	checked	\N	\N
824	8	22804	checked	\N	\N
825	8	22805	checked	\N	\N
826	8	22806	missed	\N	\N
827	8	22807	checked	\N	\N
828	8	22808	checked	\N	\N
829	8	22809	checked	\N	\N
830	8	22810	checked	\N	\N
832	8	22812	missed	\N	\N
833	8	22813	missed	\N	\N
835	8	22815	missed	\N	\N
836	8	22816	missed	\N	\N
837	8	22817	missed	\N	\N
834	8	22814	checked	for the vascular, I will be assessing. the radial pulse.	\N
831	8	22811	missed	\N	\N
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.items (id, section_id, parent_item_id, text, is_critical, points, "order", explanation, image_url, image_caption, video_url) FROM stdin;
1	1	\N	Get	f	1	0	\N	\N	\N	\N
2	2	\N	Washes hands / applies alcohol gel	f	1	0	Basic infection control. Expected at the start of any patient encounter.	\N	\N	\N
3	2	\N	Introduces self (name and role)	f	1	1	Sets the tone and opens the therapeutic relationship. Name + role + level of training is standard.	\N	\N	\N
4	2	\N	Confirms patient identity (name and date of birth)	t	1	2	Patient safety step. Two identifiers are the minimum standard before any clinical encounter.	\N	\N	\N
5	2	\N	Explains purpose of the consultation and gains consent	f	1	3	Consent is continuous, but stating the purpose up front orients the patient and respects autonomy.	\N	\N	\N
6	3	\N	Opens with a broad question (e.g., "What brings you in today?")	f	1	0	An open question invites the patient's own narrative and often yields the diagnosis before a single closed question is needed.	\N	\N	\N
7	3	\N	Allows the patient to speak uninterrupted (golden minute)	f	1	1	The first 60 seconds of uninterrupted patient speech typically contain the key diagnostic information. Interrupting too early shuts down the narrative and misses cues.	\N	\N	\N
8	4	\N	Site — where is the headache?	f	1	0	Location narrows the differential. Unilateral frontotemporal suggests migraine; bilateral band-like suggests tension-type; periorbital with autonomic features suggests cluster; temporal in older patients raises giant cell arteritis.	\N	\N	\N
9	4	\N	Onset — when and how did it start?	t	1	1	A sudden thunderclap onset reaching peak intensity within seconds to a minute is a red flag for subarachnoid hemorrhage until proven otherwise. Gradual onset over minutes to hours is more consistent with primary headache.	\N	\N	\N
10	4	\N	Character — what does the pain feel like?	f	1	2	Throbbing / pulsating suggests migraine. Tight band / pressing suggests tension-type. Sharp, stabbing, boring behind one eye suggests cluster.	\N	\N	\N
11	4	\N	Radiation — does the pain go anywhere else?	f	1	3	Radiation to the neck may suggest meningeal irritation. Radiation to the jaw with chewing raises giant cell arteritis in an older patient.	\N	\N	\N
12	4	\N	Associated symptoms	f	1	4	Classic migraine features: nausea, vomiting, photophobia, phonophobia, aura. Autonomic features (lacrimation, conjunctival injection, ptosis, rhinorrhoea) suggest cluster. Fever and neck stiffness raise meningitis.	\N	\N	\N
13	4	\N	Timing — episodic vs continuous, duration, frequency	f	1	5	Migraine attacks last 4-72 hours untreated. Cluster attacks are shorter (15-180 minutes) but in clusters. Chronic daily headache (>15 days/month) raises medication overuse. Progressive daily headache raises a space-occupying lesion.	\N	\N	\N
14	4	\N	Exacerbating and relieving factors	f	1	6	Worse on movement and with bright light or loud sound supports migraine. Worse on coughing, straining, or lying flat suggests raised intracranial pressure. Worse on sitting up / better on lying flat suggests low-pressure headache (e.g., post-LP).	\N	\N	\N
15	4	\N	Severity — 0 to 10 pain score	f	1	7	A numerical score anchors severity and allows tracking over time. It does not, on its own, distinguish primary from secondary headache.	\N	\N	\N
16	5	\N	Systemic symptoms and secondary risk factors (fever, weight loss, rash, immunocompromise, malignancy)	t	2	0	Fever with headache and neck stiffness raises meningitis. Weight loss and night sweats raise malignancy or giant cell arteritis. Known HIV or immunosuppression widens the differential to opportunistic CNS infections and lymphoma.	\N	\N	\N
17	5	\N	Neurological symptoms (focal weakness, numbness, vision loss, speech disturbance, seizures, altered consciousness)	t	2	1	Persistent focal neurological deficit or reduced GCS points to stroke, hemorrhage, space-occupying lesion, or encephalitis. Aura should fully resolve; a deficit that does not resolve is not migraine aura.	\N	\N	\N
18	5	\N	Onset — sudden / thunderclap / worst headache of life	t	2	2	Screens for subarachnoid hemorrhage, arterial dissection, reversible cerebral vasoconstriction syndrome, and pituitary apoplexy.	\N	\N	\N
19	5	\N	Older age — new-onset headache after 50	t	2	3	New headache over 50 raises giant cell arteritis and intracranial malignancy. Ask about jaw claudication, scalp tenderness, and visual disturbance.	\N	\N	\N
20	5	\N	Pattern change, Progressive, Positional, or Precipitated by valsalva / cough	t	2	4	A change in established pattern, steady progression over weeks, headache that is worse on lying flat or on waking, or headache precipitated by cough / straining / valsalva all point to raised intracranial pressure and warrant imaging.	\N	\N	\N
21	5	\N	Recent head trauma	t	2	5	Even minor trauma can cause subdural hematoma, particularly in the elderly or anticoagulated. Ask specifically — patients often do not volunteer it.	\N	\N	\N
22	5	\N	Meningism (neck stiffness, photophobia, fever together)	t	2	6	Classic triad of meningitis. Photophobia alone is non-specific (common in migraine), but combined with fever and neck stiffness it mandates urgent assessment and empirical antibiotics if suspected.	\N	\N	\N
23	6	\N	Previous similar headaches or known migraine	f	1	0	A long history of stereotyped episodic attacks strongly supports primary headache. A first-ever severe headache or a clear change in pattern is a red flag.	\N	\N	\N
24	6	\N	Hypertension	f	1	1	Poorly controlled hypertension is a risk factor for hemorrhagic stroke and hypertensive encephalopathy.	\N	\N	\N
25	6	\N	Previous head injury or neurosurgery	f	1	2	Previous injury raises post-traumatic headache and chronic subdural hematoma. Previous shunts raise shunt dysfunction.	\N	\N	\N
26	6	\N	Cancer (current or past)	f	1	3	Active or past malignancy raises cerebral metastases, particularly from lung, breast, melanoma, and renal primaries.	\N	\N	\N
27	6	\N	HIV or immunocompromise	f	1	4	Widens the differential to CNS toxoplasmosis, cryptococcal meningitis, and CNS lymphoma.	\N	\N	\N
28	6	\N	Pregnancy or recent pregnancy	f	1	5	Pregnancy and the postpartum period raise cerebral venous sinus thrombosis, eclampsia, and posterior reversible encephalopathy syndrome.	\N	\N	\N
29	7	\N	Regular prescribed medications	f	1	0	Establish baseline. Specifically note vasoactive and neurological medications.	\N	\N	\N
30	7	\N	Hormonal contraception or HRT	f	2	1	Combined oral contraception is contraindicated in migraine with aura due to increased ischemic stroke risk. This is a key management-changing question in this patient.	\N	\N	\N
31	7	\N	Frequency of analgesic use (screen for medication-overuse headache)	f	2	2	Simple analgesics used on 15 or more days per month, or triptans / opioids / combination analgesics on 10 or more days per month for more than 3 months, define medication-overuse headache. This is a common and treatable cause of chronic daily headache.	\N	\N	\N
32	7	\N	Anticoagulants or antiplatelets	f	1	3	Lowers the threshold for imaging in headache with any trauma, and raises concern for intracranial hemorrhage.	\N	\N	\N
33	7	\N	Recreational drugs (cocaine, amphetamines)	f	1	4	Sympathomimetic drugs are risk factors for intracerebral hemorrhage and reversible cerebral vasoconstriction syndrome.	\N	\N	\N
34	7	\N	Allergies	f	1	5	Standard safety check before suggesting analgesia or antiemetics.	\N	\N	\N
35	8	\N	Migraine or recurrent headache in first-degree relatives	f	1	0	Migraine has a strong familial tendency. A positive family history supports the diagnosis.	\N	\N	\N
36	8	\N	Subarachnoid hemorrhage or cerebral aneurysm	f	1	1	Two or more first-degree relatives with SAH or known berry aneurysms raises the individual's risk and changes the threshold for imaging.	\N	\N	\N
37	8	\N	Stroke at a young age or polycystic kidney disease	f	1	2	Autosomal dominant polycystic kidney disease is associated with berry aneurysms. Young stroke in the family raises hereditary coagulopathies and CADASIL.	\N	\N	\N
38	9	\N	Occupation and impact on daily life	f	1	0	Headache frequency and severity are often best captured by the number of days missed from work or study.	\N	\N	\N
39	9	\N	Stress and mood	f	1	1	Stress is a common migraine trigger and is also strongly associated with tension-type headache.	\N	\N	\N
40	9	\N	Sleep pattern	f	1	2	Both insufficient and disrupted sleep are well-established migraine triggers.	\N	\N	\N
41	9	\N	Caffeine intake	f	1	3	Caffeine excess and caffeine withdrawal both trigger headaches. Quantify cups per day.	\N	\N	\N
42	9	\N	Alcohol	f	1	4	Alcohol, especially red wine, is a common migraine trigger.	\N	\N	\N
43	9	\N	Smoking	f	1	5	Smoking plus combined oral contraception plus migraine with aura compounds stroke risk.	\N	\N	\N
44	9	\N	Recreational drug use	f	1	6	Covered for completeness; ask in a non-judgmental way.	\N	\N	\N
45	10	\N	Ideas — what does the patient think is going on?	f	1	0	Exploring the patient's own model surfaces specific fears (e.g., stroke because a relative had one) that can then be addressed directly.	\N	\N	\N
46	10	\N	Concerns — what is the patient most worried about?	f	1	1	Naming the worry allows you to address it explicitly rather than talking past it.	\N	\N	\N
47	10	\N	Expectations — what does the patient want from this visit?	f	1	2	Aligns the plan with the patient's goals (pain relief, reassurance, investigation) and reduces later dissatisfaction.	\N	\N	\N
48	11	\N	Summarises the history back to the patient	f	1	0	A brief summary checks understanding, corrects errors, and signals active listening.	\N	\N	\N
49	11	\N	Offers the patient a chance to add anything else	f	1	1	'Is there anything else you wanted to tell me?' often surfaces the real concern that was held back.	\N	\N	\N
50	11	\N	Explains next steps (examination, investigations, management plan)	f	1	2	Signposts the rest of the encounter and manages expectations.	\N	\N	\N
51	11	\N	Thanks the patient	f	1	3	Basic courtesy. Expected in every encounter.	\N	\N	\N
52	4	8	Clarifies unilateral vs bilateral	f	1	0	\N	\N	\N	\N
53	4	8	Clarifies region (frontal / temporal / occipital / periorbital)	f	1	1	\N	\N	\N	\N
54	4	9	Asks specifically about sudden / thunderclap onset	t	2	0	Directly screens for subarachnoid hemorrhage. A 'worst headache of life' peaking in under one minute mandates urgent imaging.	\N	\N	\N
55	4	9	Clarifies time to peak intensity	f	1	1	\N	\N	\N	\N
56	4	10	Throbbing / pulsating	f	1	0	\N	\N	\N	\N
57	4	10	Tight band / pressing	f	1	1	\N	\N	\N	\N
58	4	10	Sharp / stabbing / boring	f	1	2	\N	\N	\N	\N
59	4	12	Nausea and vomiting	f	1	0	\N	\N	\N	\N
60	4	12	Photophobia	f	1	1	\N	\N	\N	\N
61	4	12	Phonophobia	f	1	2	\N	\N	\N	\N
62	4	12	Visual aura (zigzags, scotoma, flashing lights)	f	2	3	Aura is a fully reversible focal neurological symptom, typically visual, preceding or accompanying the headache. Presence of aura changes management (e.g., contraindicates combined oral contraception due to stroke risk).	\N	\N	\N
63	4	12	Autonomic features (tearing, nasal congestion, ptosis)	f	1	4	Unilateral cranial autonomic symptoms point to trigeminal autonomic cephalalgias, of which cluster headache is the prototype.	\N	\N	\N
64	4	13	Duration of this attack	f	1	0	\N	\N	\N	\N
65	4	13	Frequency of similar attacks	f	1	1	\N	\N	\N	\N
66	4	13	First ever vs similar previous episodes	f	1	2	\N	\N	\N	\N
67	4	14	Movement / physical activity	f	1	0	\N	\N	\N	\N
68	4	14	Light and sound	f	1	1	\N	\N	\N	\N
69	4	14	Rest / dark quiet room / sleep	f	1	2	\N	\N	\N	\N
70	4	14	Response to analgesia taken so far	f	1	3	\N	\N	\N	\N
71	5	20	Change from usual headache pattern	f	1	0	\N	\N	\N	\N
72	5	20	Progressive (worsening over days to weeks)	f	1	1	\N	\N	\N	\N
73	5	20	Positional (worse lying flat, on waking, or on standing)	f	1	2	\N	\N	\N	\N
74	5	20	Precipitated by cough, sneeze, valsalva or exertion	f	1	3	\N	\N	\N	\N
18058	1288	\N	WIPER	f	1	0	\N	\N	\N	\N
18059	1288	18058	Introduce yourself	f	1	0	\N	\N	\N	\N
18060	1288	18058	Wash hands	f	1	1	\N	\N	\N	\N
18061	1288	18058	Permission and Privacy	f	1	2	\N	\N	\N	\N
18062	1288	18058	Explain and expose	f	1	3	\N	\N	\N	\N
18063	1288	18058	Be on right side of the patient	f	1	4	\N	\N	\N	\N
18064	1289	\N	SEADS	f	1	0	\N	\N	\N	\N
18065	1289	18064	Symmetry	f	1	0	\N	\N	\N	\N
18066	1289	18064	Swelling	f	1	1	\N	\N	\N	\N
18067	1289	18064	Scars	f	1	2	\N	\N	\N	\N
18068	1289	18064	Erythema	f	1	3	\N	\N	\N	\N
18069	1289	18064	Atrophy (PM-Deltoid, supra and infraspinatus)	f	1	4	\N	\N	\N	\N
18070	1289	18064	Deformities (clavicle Fx, step-off deformity, scapular winging, sprgnl'es deformity	f	1	5	\N	/uploads/items/f0c36f73-3509-4ad6-a89d-4bbe11d2b523.png	Step-off deformity	\N
18071	1289	\N	Functional Assessment	f	1	1	\N	\N	\N	\N
18072	1289	18071	Appley's test	f	1	0	a physical exam maneuver used to detect meniscal tears in the knee. The patient lies prone with the knee bent to \n, while the examiner applies downward pressure (compression) and rotates the tibia. A positive test is indicated by pain, clicking, or decreased rotation, indicating a potential meniscus injury.	\N	\N	https://www.youtube.com/watch?v=6Z_9lfX_Pc8
18073	1290	\N	General	f	1	0	\N	\N	\N	\N
18074	1290	18073	Tenderness	f	1	0	\N	\N	\N	\N
18075	1290	18073	Hotness	f	1	1	\N	\N	\N	\N
18076	1290	18073	Swelling	f	1	2	\N	\N	\N	\N
22753	1676	\N	Wash hands	f	1	0	\N	\N	\N	\N
18077	1290	\N	Bone	f	1	1	\N	/uploads/items/e69fe5c1-d13f-4e36-8f58-257722041898.jpg	\N	\N
18078	1290	18077	Sternum	f	1	0	\N	\N	\N	\N
18079	1290	18077	SC joint	f	1	1	\N	\N	\N	\N
18080	1290	18077	Clavicle	f	1	2	\N	\N	\N	\N
18081	1290	18077	AC joint	f	1	3	\N	\N	\N	\N
18082	1290	18077	Acromion	f	1	4	\N	\N	\N	\N
18083	1290	18077	Coracoid Process	f	1	5	\N	\N	\N	\N
18084	1290	18077	GHJ	f	1	6	\N	\N	\N	\N
18085	1290	18077	Greater tuberosity	f	1	7	\N	\N	\N	\N
18086	1290	18077	INtertubercular goorve (biceptal goove)	f	1	8	\N	\N	\N	\N
18087	1290	18077	Suprascapular spine	f	1	9	\N	\N	\N	\N
18088	1290	18077	Superior angle	f	1	10	\N	\N	\N	\N
18089	1290	18077	medial border	f	1	11	\N	\N	\N	\N
18090	1290	18077	inferior angle	f	1	12	\N	\N	\N	\N
18091	1290	18077	lateral border	f	1	13	\N	\N	\N	\N
18092	1290	\N	Muscles	f	1	2	\N	/uploads/items/841151c8-9aa0-4a96-a952-8e0e6f894c7c.png	\N	\N
18093	1290	18092	Pectoralis Major	f	1	0	\N	\N	\N	\N
18094	1290	18092	Deltoid	f	1	1	\N	\N	\N	\N
18095	1290	18092	Biceps	f	1	2	\N	\N	\N	\N
18096	1290	18092	Scalenes	f	1	3	\N	\N	\N	\N
18097	1290	18092	Levator scauplae	f	1	4	\N	\N	\N	\N
18098	1290	18092	Trapezius	f	1	5	\N	\N	\N	\N
18099	1290	18092	Rhomboid	f	1	6	\N	\N	\N	\N
18100	1290	18092	Supraspinatus	f	1	7	\N	\N	\N	\N
18101	1290	18092	Infraspinatus	f	1	8	\N	\N	\N	\N
18102	1290	\N	Bursa	f	1	3	\N	\N	\N	\N
18103	1290	18102	Subacromial	f	1	0	\N	\N	\N	\N
18104	1290	18102	Subdeltoid	f	1	1	\N	\N	\N	\N
18105	1290	\N	Axilla	f	1	4	\N	\N	\N	\N
18106	1291	\N	Active, Passive, Resisted	f	1	0	\N	\N	\N	\N
18107	1291	18106	Shoulder flexion (180 degrees)	f	1	0	\N	\N	\N	\N
18108	1291	18106	Shoulder extension (60 degrees)	f	1	1	\N	\N	\N	\N
18109	1291	18106	Shoulder Adduction (80 degrees)	f	1	2	\N	\N	\N	\N
18110	1291	18106	Shoulder Abduction (180 degrees)	f	1	3	\N	\N	\N	\N
18111	1291	18110	Up to 15 degrees: supraspinatus	f	1	0	\N	\N	\N	\N
18112	1291	18110	15-90 degrees: deltoid	f	1	1	\N	\N	\N	\N
18113	1291	18110	More than 90 degrees: Trapezius and serratus anterior	f	1	2	\N	\N	\N	\N
18114	1291	18106	External Rotation (90 degrees)	f	1	4	\N	\N	\N	\N
18115	1291	18106	Internal Rotation (90 degrees)	f	1	5	\N	\N	\N	\N
18116	1292	\N	Impingement	f	1	0	\N	\N	\N	\N
18117	1292	18116	Neer's Test	f	1	0	Passive flexion of an internally rotated shoulder.	/uploads/items/a2d68f49-4954-4aa8-842e-97b438400b0b.png	\N	https://www.youtube.com/watch?v=k21FNtBjQ14
18118	1292	18116	Hawkins-Kennedy Test	f	1	1	Passive shoulder flexion to 90 with added internal rotation. 	/uploads/items/c5ce18b7-a95b-4608-b24e-6a50f21b414c.png	\N	https://youtu.be/6GkKB2oXi3o?si=4OtDSglTZSe_SSVW&t=36
18119	1292	18116	Painful arc	f	1	2	Painful ACTIVE abduction between 60-120 degrees abductiona	/uploads/items/1ef3e4ca-2d65-46a9-901b-cbb6f26b493a.png	\N	\N
18120	1292	\N	Rotator cuff	f	1	1	\N	\N	\N	\N
369	36	\N	WIPER	f	1	0	\N	\N	\N	\N
370	36	369	Introduce yourself	f	1	0	\N	\N	\N	\N
371	36	369	Wash hands	f	1	1	\N	\N	\N	\N
372	36	369	Permission and Privacy	f	1	2	\N	\N	\N	\N
373	36	369	Explain and expose	f	1	3	\N	\N	\N	\N
374	36	369	Be on right side of the patient	f	1	4	\N	\N	\N	\N
375	37	\N	SEADS	f	1	0	\N	\N	\N	\N
376	37	375	Symmetry	f	1	0	\N	\N	\N	\N
377	37	375	Swelling	f	1	1	\N	\N	\N	\N
378	37	375	Scars	f	1	2	\N	\N	\N	\N
379	37	375	Erythema	f	1	3	\N	\N	\N	\N
380	37	375	Atrophy (PM-Deltoid, supra and infraspinatus)	f	1	4	\N	\N	\N	\N
381	37	375	Deformities (clavicle Fx, step-off deformity, scapular winging, sprgnl'es deformity	f	1	5	\N	/uploads/items/f0c36f73-3509-4ad6-a89d-4bbe11d2b523.png	Step-off deformity	\N
382	37	\N	Functional Assessment	f	1	1	\N	\N	\N	\N
383	37	382	Appley's test	f	1	0	a physical exam maneuver used to detect meniscal tears in the knee. The patient lies prone with the knee bent to \n, while the examiner applies downward pressure (compression) and rotates the tibia. A positive test is indicated by pain, clicking, or decreased rotation, indicating a potential meniscus injury.	\N	\N	https://www.youtube.com/watch?v=6Z_9lfX_Pc8
384	38	\N	General	f	1	0	\N	\N	\N	\N
385	38	384	Tenderness	f	1	0	\N	\N	\N	\N
386	38	384	Hotness	f	1	1	\N	\N	\N	\N
387	38	384	Swelling	f	1	2	\N	\N	\N	\N
388	38	\N	Bone	f	1	1	\N	/uploads/items/e69fe5c1-d13f-4e36-8f58-257722041898.jpg	\N	\N
389	38	388	Sternum	f	1	0	\N	\N	\N	\N
390	38	388	SC joint	f	1	1	\N	\N	\N	\N
391	38	388	Clavicle	f	1	2	\N	\N	\N	\N
392	38	388	AC joint	f	1	3	\N	\N	\N	\N
393	38	388	Acromion	f	1	4	\N	\N	\N	\N
394	38	388	Cricoid	f	1	5	\N	\N	\N	\N
395	38	388	GHJ	f	1	6	\N	\N	\N	\N
396	38	388	Greater tuberosity	f	1	7	\N	\N	\N	\N
397	38	388	INtertubercular goorve (biceptal goove)	f	1	8	\N	\N	\N	\N
398	38	388	Suprascapular spine	f	1	9	\N	\N	\N	\N
399	38	388	Superior angle	f	1	10	\N	\N	\N	\N
400	38	388	medial border	f	1	11	\N	\N	\N	\N
401	38	388	inferior angle	f	1	12	\N	\N	\N	\N
402	38	388	lateral border	f	1	13	\N	\N	\N	\N
403	38	\N	Muscles	f	1	2	\N	\N	\N	\N
404	38	403	Pectoralis Major	f	1	0	\N	\N	\N	\N
405	38	403	Deltoid	f	1	1	\N	\N	\N	\N
406	38	403	Biceps	f	1	2	\N	\N	\N	\N
407	38	403	Scalenes	f	1	3	\N	\N	\N	\N
408	38	403	Levator scauplae	f	1	4	\N	\N	\N	\N
409	38	403	Trapezius	f	1	5	\N	\N	\N	\N
410	38	403	Rhomboid	f	1	6	\N	\N	\N	\N
411	38	403	Supraspinatus	f	1	7	\N	\N	\N	\N
412	38	403	Infraspinatus	f	1	8	\N	\N	\N	\N
413	38	\N	Bursa	f	1	3	\N	\N	\N	\N
414	38	413	Subacromial	f	1	0	\N	\N	\N	\N
415	38	413	Subdeltoid	f	1	1	\N	\N	\N	\N
416	38	\N	Axilla	f	1	4	\N	\N	\N	\N
417	39	\N	Activeeeff	f	1	0	\N	\N	\N	\N
18121	1292	18120	Empty can (Supraspinatus)	f	1	0	Resisted abduction with patient shoulders in 90 degrees abduction, 30 horizontal adduction and full internal rotation (thumbs down)	/uploads/items/56f505c8-0bc5-4dcd-a7a7-42934879e909.png	\N	\N
18122	1292	18120	Drop Arm Test (Supraspinatus)	f	1	1	Abduct shoulder to 90 and ask patient to hold briefly then slowly lower the arm	/uploads/items/93329d1b-fa65-4885-9574-dd203b0ae305.png	\N	\N
18123	1292	18120	Lift off Test (Subscapularis)	f	1	2	Shoulder internally rotated and extended, elbow at 90, resistance to hand lift off.	/uploads/items/1905bd47-2f4e-43d8-aeb6-6d238b32b772.png	\N	\N
18124	1292	18120	Bear Hug Test (Subscapularis)	f	1	3	Hand on contralateral shoulder, patient resists external rotation force. (The tester pulls the hand away for the chest or shoulder)	/uploads/items/db810b7a-bd5d-4332-8692-05bde675a847.png	\N	\N
18125	1292	\N	Acromio-clavicular Joint	f	1	2	\N	\N	\N	\N
18126	1292	18125	Scarf test	f	1	0	90 degrees flex arm then is forcibly adducted to the contralateral side, if patient feels pain at the AC joint then it's positive.	/uploads/items/250b2792-c8d0-4f1e-87d0-ca31a42fa41f.png	\N	\N
18127	1292	18125	Painful Arc	f	1	1	Painful ACTIVE abduction between 60-120 degrees abduction	\N	\N	\N
18128	1292	\N	Instability of the shoulder	f	1	3	\N	\N	\N	\N
18129	1292	18128	Apprehension Test	f	1	0	Pressure is applied to the posterior humerus while the arm is flexed and abducted at 90 degrees, pain and increased ROM for external rotaiton.	/uploads/items/60056206-8535-4dec-b9ff-382f953f5c8a.png	\N	\N
18130	1292	18128	Relocation Test	f	1	1	While the patient is lying down, examiner applies downward pressure from the anterior aspect of the humerues while the arm is flexed and abducted at 90 degrees, relieves pain	/uploads/items/e7aa7b68-a649-4c53-86ed-18b6ef68a3d1.png	\N	\N
18131	1292	\N	Laxity of the shoulder	f	1	4	\N	\N	\N	\N
18132	1292	18131	Sulcus sign	f	1	0	While the patient is sitting, pulldown the arm, if there is laxity of the superior glenohumeral and coracohumeral ligaments, there will be a pit or sulcus near the shoulder.	/uploads/items/67c80ba2-2666-495c-9d3a-758bc9b5eb04.png	\N	\N
18133	1292	\N	SLAP tear (Superior Labrum Anterior to Posterior)	f	1	5	\N	\N	\N	\N
18134	1292	18133	O'Brian's Test	f	1	0	Ask the patient to do shoulder flexion of 90 degrees, put pressure while the arm is internally rotated, then while it's externally rotated. Positive for pain.	/uploads/items/486dc958-0ae0-4041-89cc-b3ffa4d5ed16.png	\N	\N
18135	1292	\N	Biceps tendonitis	f	1	6	\N	\N	\N	\N
18136	1292	18135	Speed's test	f	1	0	Ask the patient to flex shoulder at 90 degrees, externally rotated his arm with elbow extended, then you put pressure at the and of the forearm.	/uploads/items/f87d11bf-819e-4da9-b2c0-76bbf34eac02.png	\N	\N
18137	1292	18135	Yergason's Test	f	1	1	Patient's elbow should be flexed to 90 degrees, forearm pronated, patient resists forearm supination and external rotation while examiner palpates bicipital groove.	/uploads/items/4dea819f-88bb-4fda-82ed-f73ba01c10f3.png	\N	https://www.youtube.com/watch?v=JMKwNRLHIvY
18138	1292	\N	Thoracic Outlet Syndrome	f	1	7	Thoracic outlet syndrome (TOS) is a group of conditions in which there's pressure on blood vessels or nerves in the area between the neck and shoulder. 	\N	\N	\N
18139	1292	18138	Adson Test	f	1	0	Locate the radial pulse, extend the shoulder, ask patient to extend and rotate his head to the extended hand then take a breath and hold it. positive test, pulse reduction and reproduction of symptoms. (Looking to the son who's holding the hand from below)	/uploads/items/42eb6e3e-1ba1-406c-b41f-00862ac4d6d5.png	\N	https://youtu.be/-7346RaEGKU?si=HP-YL5wmA-8bNNl4&t=46
18140	1292	18138	Allen Test	f	1	1	Locate the radial pulse, abduct the shoulder and externally rotate it. Patient extends his neck and rotate it toward the other side, takes a deep breath and hold it. (Looking away from the alien who's abducting him up)	/uploads/items/b45a23f0-821a-4cc1-ad9d-62e0d8ab4dec.png	\N	\N
18141	1292	18138	Roos Test	f	1	2	Shoulder abducted to 90, patient opens and closes hands for 3 minutes. 	/uploads/items/3d233152-f2d7-4e87-9d85-4fcd4076526a.png	\N	\N
18142	1293	\N	Reflexes	f	1	0	\N	\N	\N	\N
18143	1293	18142	Biceps: C5-C6	f	1	0	\N	\N	\N	\N
18144	1293	18142	Triceps C7-C8	f	1	1	\N	\N	\N	\N
18145	1293	18142	Brachio-radialis C5-C6	f	1	2	\N	\N	\N	\N
18146	1293	\N	Vascular	f	1	1	\N	\N	\N	\N
18147	1293	18146	Axillary pulse	f	1	0	\N	\N	\N	\N
18148	1293	18146	Radial pulse	f	1	1	\N	\N	\N	\N
18149	1293	\N	Sensory	f	1	2	\N	/uploads/items/d8f13697-d14b-4aea-bbc5-729d2dd78baf.png	\N	\N
18150	1293	18149	C4 (Over deltoid)	f	1	0	\N	\N	\N	\N
18151	1293	18149	C5 (Lateral aspect of the arm)	f	1	1	\N	\N	\N	\N
18152	1293	18149	C6 (Base of the thumb)	f	1	2	\N	\N	\N	\N
18153	1293	18149	C7 (Middle finger)	f	1	3	\N	\N	\N	\N
18154	1293	18149	C8 (Little finger)	f	1	4	\N	\N	\N	\N
18155	1293	18149	T1 (Medial side of elbow)	f	1	5	\N	\N	\N	\N
18156	1294	\N	Examine Joint above and below	f	1	0	\N	\N	\N	\N
18157	1294	\N	Cover the patient and thank them	f	1	1	\N	\N	\N	\N
18158	1294	\N	Explain the findings and summarize	f	1	2	\N	\N	\N	\N
22754	1676	\N	Introduce Self	f	1	1	\N	\N	\N	\N
22755	1676	\N	Permission and Privacy	f	1	2	\N	\N	\N	\N
22756	1676	\N	Explain and Exposure	f	1	3	\N	\N	\N	\N
22757	1676	\N	Be on Right side of the patient	f	1	4	\N	\N	\N	\N
22758	1677	\N	SEADS	f	1	0	\N	\N	\N	\N
22759	1677	22758	Symmetry	f	1	0	\N	\N	\N	\N
22760	1677	22758	Swelling	f	1	1	\N	\N	\N	\N
22761	1677	22758	Scars	f	1	2	\N	\N	\N	\N
22762	1677	22758	Erythema	f	1	3	\N	\N	\N	\N
22763	1677	22758	Atrophy	f	1	4	\N	\N	\N	\N
22764	1677	22763	Deltoid	f	1	0	\N	\N	\N	\N
22765	1677	22763	Biceps	f	1	1	\N	\N	\N	\N
22766	1677	22763	Triceps	f	1	2	\N	\N	\N	\N
22767	1677	22763	Thenar	f	1	3	\N	\N	\N	\N
22768	1677	22763	Hypothenar	f	1	4	\N	\N	\N	\N
22769	1677	22758	Deformities	f	1	5	\N	\N	\N	\N
22770	1677	22769	Waiter's Tip or Erb's Palsy (Upper trunk of brachial plexus)	f	1	0	\N	/uploads/items/e04fe209-27d8-42a8-83a4-602bce2e25ea.png	\N	\N
22771	1677	22769	Claw Hand (Lower trunk of brachial plexus)	f	1	1	\N	/uploads/items/321c4fd8-6afd-4889-8c0b-28584e22d0ae.png	\N	\N
22772	1677	22769	Wrist Drop (Radial Nerve)	f	1	2	\N	/uploads/items/4b7819e7-c5f7-4578-9f96-b255126cfc55.png	\N	\N
22773	1677	22769	Benediction Sign (Median Nerve, Anterior interousses nerve)	f	1	3	\N	/uploads/items/7bf734da-5acf-434d-9281-17f4ba8f03b3.png	\N	\N
22774	1677	22769	Ulnar Claw Hand (Last two digits, Ulnar Nerve)	f	1	4	\N	/uploads/items/b5ae1fc1-f756-425f-8ae3-8446191aec7d.png	\N	\N
22775	1677	22769	Winged Scapula (Long Thoracic Nerve)	f	1	5	\N	/uploads/items/201dd9b2-a0e2-4675-ac14-8816efe93961.png	\N	\N
22776	1678	\N	Dermatomes by Trunks	f	1	0	\N	/uploads/items/e589197f-0cc3-4c9c-be8d-a1ed50a858e3.png	\N	\N
22777	1678	22776	Upper Trunk	f	1	0	\N	\N	\N	\N
22778	1678	22777	C4 (Top of shoulder)	f	1	0	\N	\N	\N	\N
22779	1678	22777	C5 (Lateral upper arm)	f	1	1	\N	\N	\N	\N
22780	1678	22777	C6 (Base of the thumb)	f	1	2	\N	\N	\N	\N
22781	1678	22776	Middle Trunk	f	1	1	\N	\N	\N	\N
22782	1678	22781	C7 (Tip of middle finger)	f	1	0	\N	\N	\N	\N
22783	1678	22776	Lower Trunk	f	1	2	\N	\N	\N	\N
22784	1678	22783	C8 (Tip of little finger)	f	1	0	\N	\N	\N	\N
22785	1678	22783	T1 (Medial upper arm)	f	1	1	\N	\N	\N	\N
22786	1678	\N	Peripheral Nerves Sensory	f	1	1	\N	/uploads/items/430a579d-dee1-4f67-84a8-5fd1c165ce36.png	\N	\N
22787	1678	22786	Axillary Nerve (Over deltoid)	f	1	0	\N	\N	\N	\N
22788	1678	22786	Musculocutaneous Nerve (Lateral forearm)	f	1	1	\N	\N	\N	\N
22789	1678	22786	Radial Nerve (Dorsal first web space)	f	1	2	\N	\N	\N	\N
22790	1678	22786	Medial Nerve (Plamar surface of thumb, index middle and and lateral half of ring finger)	f	1	3	\N	\N	\N	\N
22791	1678	22786	Ulnar Nerve (Tip of the little finger)	f	1	4	\N	\N	\N	\N
22792	1678	22786	Medial Cutaneous Nerve of Forearm (Medial side of forearm)	f	1	5	\N	\N	\N	\N
22793	1678	22786	Medial Cutaneous Nerve of the Arm (Medial side of arm)	f	1	6	\N	\N	\N	\N
22794	1679	\N	Spinal Accessory Nerve (Trapezius) - Shoulder elevation	f	1	0	\N	\N	\N	\N
22795	1679	\N	Dorsal Scapular Nerve (Rhomboids) - Move hands against examiner like lift-off test)	f	1	1	\N	\N	\N	\N
22796	1679	\N	Long Thoracic Nerve (Serratus Anterior) - Push against wall and assess for winging	f	1	2	\N	/uploads/items/a9a67cc6-da86-4d8c-8a71-da30d8b5b72a.png	\N	\N
22797	1679	\N	Lateral and medial pectoral nerves (Pectoralis Major) - Shoulder adduction against resistance	f	1	3	\N	/uploads/items/7b87c0e0-2f13-49a9-a090-b382dbaa8a0d.png	\N	\N
22798	1679	\N	Thoracodorsal Nerve (Latissimus Dorsi) - Upper Arm Adduction while flexed	f	1	4	\N	/uploads/items/6d4d2396-2c37-49db-a26a-dafc8e478110.png	\N	\N
22799	1679	\N	Subscapular Nerve (Teres Major) - Upper Arm External Rotation	f	1	5	\N	/uploads/items/e5ce65c2-9e95-4f7c-bceb-880ae248fae6.png	\N	\N
22800	1679	\N	Suprascapular Nerve (Supraspinatus) - Abduction of Arm	f	1	6	\N	/uploads/items/d6156775-d9f6-4165-8319-3462108e7cd3.png	\N	\N
22801	1679	\N	Axillary Nerve (Deltoid) - Upper Arm Abduction	f	1	7	\N	/uploads/items/1f8db6d9-dab3-4d63-97e7-fc646a45e7cf.png	\N	\N
22802	1679	\N	Musculocutaneous Nerve (Biceps) - Elbow Flexion	f	1	8	\N	\N	\N	\N
22803	1679	\N	Radial Nerve (Triceps) - Elbow Extension	f	1	9	\N	\N	\N	\N
22804	1679	\N	Posterior Interosseous nerve (ECU) - Wrist Extension	f	1	10	\N	\N	\N	\N
22805	1679	\N	Median Nerve (Pronator Teres) - Forearm Pronation	f	1	11	\N	\N	\N	\N
22806	1679	\N	Anterior Interosseuous nerve (Flexor Pollicis Longus) - Flexion of distal thumb	f	1	12	\N	\N	\N	\N
22807	1679	\N	Ulnar Nerve (Abductor Digiti Minimi) - Little finger abduction	f	1	13	\N	\N	\N	\N
22808	1680	\N	Reflexes	f	1	0	\N	\N	\N	\N
22809	1680	22808	Biceps: C5-C6	f	1	0	\N	\N	\N	\N
22810	1680	22808	Triceps: C7-C8	f	1	1	\N	\N	\N	\N
22811	1680	22808	Brachio-radialis: C5-C6	f	1	2	\N	\N	\N	\N
22812	1680	\N	Vascular	f	1	1	\N	\N	\N	\N
22813	1680	22812	Axillary pulse	f	1	0	\N	\N	\N	\N
22814	1680	22812	Radial pulse	f	1	1	\N	\N	\N	\N
22815	1681	\N	Compare other side and examine lower limbs	f	1	0	\N	\N	\N	\N
22816	1681	\N	Cover patient and thank them	f	1	1	\N	\N	\N	\N
22817	1681	\N	Explain the findings and summarize	f	1	2	\N	\N	\N	\N
\.


--
-- Data for Name: mock_exam_attempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mock_exam_attempts (id, mock_exam_id, user_id, attempt_number, current_station_index, overall_score, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: mock_exams; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mock_exams (id, user_id, title, station_ids, rest_seconds, practice_mode, status, current_station_index, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: password_resets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.password_resets (id, user_id, token, expires_at, used_at, requested_ip, created_at) FROM stdin;
1	1	1524f39a37473a0250a52821a5536714969204af093cd69f6d8a77e7cc8cdefc	2026-05-08 23:40:25.685	\N	5.163.176.88	2026-05-08 22:40:25.687303
\.


--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reports (id, target_type, target_id, reporter_id, reason, status, reviewed_by, reviewed_at, notes, created_at) FROM stdin;
\.


--
-- Data for Name: sections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sections (id, station_id, title, "order", description, image_url, image_caption) FROM stdin;
1	1	SectioHeyn 1	0	\N	\N	\N
2	2	Introduction & Rapport	0	\N	\N	\N
3	2	Presenting Complaint	1	\N	\N	\N
4	2	History of Presenting Illness (SOCRATES)	2	Structured pain history using the SOCRATES mnemonic: Site, Onset, Character, Radiation, Associated symptoms, Timing, Exacerbating/relieving, Severity.	\N	\N
5	2	Red Flag Screen (SNOOP)	3	Systematic screen for features of secondary headache: Systemic, Neurological, Onset, Older, Pattern/Progressive/Positional/Precipitated.	\N	\N
6	2	Past Medical History	4	\N	\N	\N
7	2	Drug History	5	\N	\N	\N
8	2	Family History	6	\N	\N	\N
9	2	Social History	7	\N	\N	\N
10	2	Ideas, Concerns, Expectations (ICE)	8	\N	\N	\N
11	2	Closure	9	\N	\N	\N
36	3	WIPER	0	\N	\N	\N
37	3	Look	1	\N	\N	\N
38	3	Feel 	2	\N	\N	\N
39	3	Move	3	\N	\N	\N
1288	4	WIPER	0	\N	\N	\N
1289	4	Look	1	\N	\N	\N
1290	4	Feel 	2	\N	\N	\N
1291	4	Move	3	\N	\N	\N
1292	4	Special Tests	4	IRAI-LSBT (Impingement, Rotator cuff, AC Joint, Instability, Laxity, SLAP, Bicipital Tendonitis, Thoracic Outlet syndrome.)	\N	\N
1293	4	Neuro-vascular	5	\N	\N	\N
1294	4	Conclusion	6	\N	\N	\N
1676	5	WIPER	0	\N	\N	\N
1677	5	Inspection	1	\N	\N	\N
1678	5	Sensory	2	\N	\N	\N
1679	5	Motor	3	\N	\N	\N
1680	5	Neuro-Vascular	4	\N	\N	\N
1681	5	Conclusion	5	\N	\N	\N
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, user_id, station_id, mode, time_limit_seconds, time_used_seconds, total_score, critical_items_missed, transcript, mock_exam_id, mock_exam_attempt_id, started_at, ended_at) FROM stdin;
1	2	4	ai_observer	420	726	100	f	\N	\N	\N	2026-05-09 18:19:08.826563	2026-05-09 18:31:25.961
2	2	4	ai_observer	420	348	0	f	And now starts another timer or sorry now I go into another page that says listening Okay, and there is the time at the small timer above, which is basically a bar. Now, what I want to do is that I want to switch that bar, okay, into the same. timer design that we had previously. That was in the previous page. Okay, that was in the previous page that had the begin button. because training on timing is one of the most important things. So I should be able to see the time. more visually and for it to be an important part of the UI instead of the listening, okay? Also, I should have a button that says hide timer or show timer, because sometimes I want to do it without a timer. without seeing the timer like in the same page that the exam has started I can click either high timer or show timer, but the default is the for the timer to be shown. All right, another thing is that it's not enough to say that this is over time. No, I actually. need to know how far I've exceeded the time, so that I can... Let's try to be faster Even like in the same station while I go so this is something you should go and fix right now and enhance. Thanks for watching! Thank you for watching! Got it? Deal fals arrow. No I don't think I believe you, Jesus. to death Thank you so much for watching, and I'll see you in the next video. If you didn't subscribe, you don't know what I'm doing, I'm challenging Ghassan. I'm telling you, what are you doing? What are you doing? Get inside. Get inside. Thank you for watching! Thank you for watching! Thank you for watching! I'm going to put the link in the description. I hope you enjoy the video. Thank you for watching. I'll see you in the next video. Bye. Thanks for watching and don't forget to like and subscribe! This is just a trick warning that there will be lots and lots of unsatisfying videos in this video. Counting. Digging around in there. Just gonna see where you can go away. I'll cut some head off. I don't want you. I'm a girl with asthma. Everybody going down in these kids. See, we get to the end, but that's where we begin. You feel it? Many kids, and we bring it out. We bring it out, and we bring in the codes. Similar to the Jekyll and Hyde, to the Jacksonville, everybody. and and and and and There she goes! Ow! Ow! Thank you so much for watching. I'll see you in the next video. So low travel tip number one say hi to the first person say hi to the first person when you walk to the bar, the first person you see say hi. When you walk into the hostel, it's the very first person you see say hi. If you can walk into the room and say hi immediately, you will break that barrier of feeling uncomfortable. If you walk in and you say, I don't know if I should say hi to that person, I don't know who to talk to, you're gonna keep doing that the entire night, the entire night.	\N	\N	2026-05-09 18:54:03.725172	2026-05-09 18:59:52.447
5	2	4	ai_observer	420	566	95	f	May I confirm your name and age please? All right, nice to see you Khaled, I'll be washing my hands, okay so Khaled today I will Do a shoulder examination that would be include me moving and touching your shoulder would that be okay with you? All right, I assure you total privacy of the session. Okay Harad can you please remove your shirt so we ensure proper exposure and I will be on the right side of the patient. Okay, I will start with inspection. I will look for any swelling, any asymmetry, any scars. I will also look for... as well as any atrophy and pectoralis major, deltoid. I will also look for any deformities such as clavicular fractures, Pringles deformity, I will also look at the scapular winging. Can you please extend your hand against the wall? All right, thank you. And then I will compare both shoulders. also now start my palpation are you sorry I will also inspect the axial and now I will start my palpation I will I will palpate first of all for any tenderness, hotness, as well as swelling. And then I will start palpating the bone with the stick. them stay in the clavicular joint clavicle acromion clavicular joint acromion coracoid prostate greater humeral joint, greater tuberosity of the humerus, bicipital groove, superior angle of the scapula, medial border, of this pat's scapulolateral border. We will also palpate the muscles, pectoralis major, deltoid, biceps, trapezius, elevator scapulae, supraspinatus, infraspinatus, rhomboid and I will also palpate the subacromia. Labianil Bursa as well as Subdeltoid Bursa and I will palpate the axilla. After that I will start my movement, can you first of all touch your back, scratch your back. This is Apley's test, checking for a functional assessment. that can you please extend your hands backwards like a shoulder extension can you do like this shoulder flexion can you do like this shoulder adduction and like this shoulder abduction for each one I'm doing passive and active after that Let's also do the external rotation and internal rotation. And now I will do it against resistance, so do like this shoulder flexion, shoulder extension, shoulder adduction, abduction, external rotation, internal rotation, all against resistance. After that, I would like you to put your hands against the wall, try to push the wall, this is for winging scapula. Then I will start the special tests, starting with the impingement, with the NIRS test. internal rotation and put your hand above try to do shoulder flexion I will do it passively So, this is Nier's test, and then Hawkins and Kennedy test, shoulder flexion with internal rotation. I will do it. Passively looking for any pain and after that painful arc test Okay, and after that I will do the Rotator cuff with the empty can tests, slight abduction, shoulder flexion and spination of complete internal rotation. After that I will do the drop arm test for supraspinatus. And I will also do the lift-off test for subscapularis. As well as bear hug test, try to resist me, yes, for subscapular. After that, I will check for the AC joint with the SCARF test. I will do complete adduction. Okay, looking for any pain, and after that, I will check for shoulder instability by doing apprehension tests, moving. While the patient is sitting or lying down, I will put my hand to the humerus and put pressure. And then from the anterior side, put pressure for the ruric. relocation test. So we did apprehension and relocation. After that... For I'll do the laxity test to put the hands down for the sulcus sign or sulcus test after that I will check for slap injury, for O'Brien's, do shoulder flexion against resistance while it's externally rotated and then while it's internally rotated. I will then do the bicipital tendinitis test by doing speed tests. Thanks for watching. test I will do, the hand will be flexed at 90 degrees, the elbow, and then I will ask patient to try to do supination and external rotation, and I will resist him. I will look for any pain. And lastly, I will check for thoracic outstretching. syndrome it downward with shoulder extension and then I will extend the head and I will tell him to look at the side, look at me or at the side of the extended shoulder, and then to take, hold your breath. Okay, and now for, this is for ads. test, sorry, and now for Allen test, I will let him, I will raise the hand above, same thing for the radial pulse, let him to look at the contralateral. side and tell him to hold his breath. And now for Ruth's test, I would like you to open and close your hand fast while raising it. Ruth's test. Alright, after that I will do neurovascular examination by checking the reflexes. biceps reflex c5 c6 triceps reflex c7 c8 brachioradialis c5 c6 I will also check the axillary pulse as well as the radial pulse. I will also check the sensation, lateral aspect C4, lateral aspect of the arm C5. of the deltoid, sorry, C4, C5, lateral aspect of the arm, C6, the base of the thumb, C7, the middle finger, little finger. for C8 and T1 for the median aspect of the elbow. I will also do an examination in conclusion. for the joint above and joint below. I will compare both shoulders. I will summarize the findings for the patient and I will also do I will also thank the patient and do a full, I will cover the	\N	\N	2026-05-09 19:16:03.475071	2026-05-09 19:25:34.044
8	2	5	ai_observer	420	371	89	f	=== NARRATION ===\nOk, Assalamu Alaikum, this is Dr. Nasser Al Harbi, I'm a physiatry resident. i would be washing my hands so may i confirm your name and age please all right nice to meet you so today the examination would include me touching and moving your upper limbs, would that be okay with you? All right, thank you. Are you sure total privacy of this? session. If you would please just remove your shirt and I will be on the right side of the patient. So first of all I will be starting with an inspection. I will look for any asymmetry in the upper limbs, any swelling, any scars. femur muscle looking for any atrophy in deltoid, biceps, triceps, thenar and hypothenar. muscles. And now I'll also be looking for deformities, starting with waiter's toe. deformity for the upper trunk, claw hand complete for the lower trunk. wrist drop for the radial nerve, a Benedict sign for the median nerve. as well as ulnar claw hand in the last two digits for the ulnar nerve and can you please extend your hand above and touch the against the wall. This is me assessing the winged scapula for of the long thoracic nerve. All right, and now I'll head to the sensory component. I will start by the dermatome distribution of the trachea. starting with the upper trunk, C4 at the top of the shoulder, C5 at the lateral upper arm. as well as C6 at the base of the thumb and for the middle trunk C7 tip of the middle finger and for the lower rank C8 for the tip of the little finger as well as medial upper arm for T1. I'll be assessing the peripheral sensory components, the axillary nerve, over the deltoid, musculocutaneous in the lateral forearm below the elbow, as well as radial nerve at the dorsal aspect of the thigh. of the first web space, the median nerve for the palmar surface of the thumb. index, middle finger, and lateral half of the ring finger. also assess the ulnar nerve at the tip of the little finger, and then medial cutaneous nerve of the little finger. the forearm, the medial side of the forearm, as well as the medial cutaneous nerve of the arm at the medial side of the arm. So, this is for the sensory. And now for the motor, I will start with the spinal acupuncture. accessory nerve by elevating the shoulders, assessing trapezius muscle. And then I will assess the dorsal scapular nerve. nerve by the rhomboids doing a liftoff test and moving hands against the left. from the back. And then I will assess the lateral and medial pictorial nerves by doing arm adduction. flexed or shoulder adduction and then after the pectoral nerve I will be assessing the thoracodone by the upper arm adduction and then upper arm external rotation for the subscapular. After that, I will be assessing the suprascapular. scapular nerve for the abduction of the arm and then the axillary nerve for the upper abduction of the arm and then the musculocutaneous nerve for biceps, elbow flexion, and then radial nerve for triceps. external extension and then posterior interosseous nerve for the wrist extension and then medial nerve for forearm pronation and then ulnar nerve for the little finger abduction. After that I will head to neurovascular, starting with reflexes for the biceps, C5, C6. and the triceps, C7, C8. And for the vascular, I will be assessing. the radial pulse. And in conclusion, I will compare both sides. I will examine the lower limbs as well. And thank you Khaled for cooperating with me today. I didn't find any abnormal. If you have any questions I'm ready to hear them. All right, thank you.	\N	\N	2026-05-10 21:50:13.020808	2026-05-10 21:56:31.064
\.


--
-- Data for Name: station_stars; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.station_stars (user_id, station_id, created_at) FROM stdin;
2	4	2026-05-09 14:42:40.794246
\.


--
-- Data for Name: stations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stations (id, user_id, title, type, default_time_minutes, reading_time_minutes, scenario, patient_briefing, has_patient_briefing, ai_patient_enabled, specialty, difficulty, tags, custom_vocabulary, reference_image_url, reference_image_caption, fork_of, visibility, published_at, star_count, fork_count, practice_count, created_at, updated_at) FROM stdin;
1	1	Test	physical_exam	7	1	\N		f	f	\N	\N	[]	[]	\N	\N	\N	private	\N	0	0	0	2026-04-25 17:44:58.364489	2026-04-25 17:44:58.364489
2	1	Headache — History Taking	history_taking	8	1	You are a doctor in the emergency department. A 34-year-old woman, Sarah Mitchell, presents with a 2-day history of severe headache. Take a focused history. You will be asked questions by the examiner at the end.	You are Sarah Mitchell, a 34-year-old graduate student. You have come to the emergency department because of a severe headache that started 2 days ago.\n\nOpening line (say only this when the doctor first asks what brought you in): "I've had this awful headache for two days now and it's not going away. I'm really worried — my aunt had a stroke."\n\nAnswer questions clearly but do not volunteer information unless asked directly. Be calm but anxious. Use lay language, not medical terms.\n\nHistory of presenting complaint (give these details only when asked the matching question):\n- Site: right-sided, behind and above the eye, sometimes spreads to the right temple. Not the whole head.\n- Onset: came on gradually over about an hour. Not a sudden thunderclap. Not the worst headache of your life — severe, but it built up.\n- Character: throbbing, pulsating. Like a drum beating.\n- Radiation: spreads from behind the right eye to the right temple. Does not go to the neck, jaw or arm.\n- Associated symptoms: feel nauseous, vomited twice yesterday. Light hurts your eyes (you dimmed the ED lights). Loud noise makes it worse. Before the headache started you saw 'shimmery zigzag lines' in your vision for about 20 minutes — they went away before the pain started. No weakness, no numbness, no trouble speaking, no loss of consciousness, no seizures, no fever, no neck stiffness, no rash, no recent head injury.\n- Timing: episodic. You get headaches like this roughly once a month, usually lasting 1 to 2 days. This one feels similar to previous ones but more severe. No headache at night waking you up.\n- Exacerbating: bright light, loud noise, bending over, climbing stairs. Movement makes it worse.\n- Relieving: lying still in a dark quiet room helps a bit. You took ibuprofen but it did not help this time.\n- Severity: 8 out of 10.\n\nRed flag screen (answer NO to all of these unless asked): no fever, no weight loss, no rash, no focal weakness, no vision loss (only the brief zigzags before the headache), no seizures, no altered consciousness, no sudden thunderclap onset, no headache worse on coughing or straining, no headache waking you from sleep, no recent head trauma, no new headache pattern (you've had similar but milder attacks before), no headache on lying flat that gets worse.\n\nPast medical history: generally well. No hypertension, no diabetes, no cancer, no HIV, no previous head injury. You have had similar but milder headaches since you were a teenager — you just called them 'bad headaches' and never saw a doctor about them.\n\nDrug history: combined oral contraceptive pill (Microgynon) for 3 years. Ibuprofen and paracetamol as needed for headaches, maybe 4-5 days per month. No regular opioids. No anticoagulants. No recent new medications. No known drug allergies.\n\nFamily history: your mother had migraines. Your aunt (mother's sister) had a stroke at age 62. No known brain aneurysms or subarachnoid hemorrhage in the family.\n\nSocial history: you are a graduate student in molecular biology. You live with your partner. You drink about 3 cups of coffee a day. You drink 2-3 glasses of wine on weekends. You do not smoke. No recreational drugs. You have been sleeping poorly — 5 to 6 hours a night — and you are stressed about an upcoming thesis deadline.\n\nICE:\n- Ideas: you think this might be a stroke because your aunt had one.\n- Concerns: you are worried something serious is happening in your brain. You are also worried about missing your thesis deadline.\n- Expectations: you want the pain to stop and you want someone to tell you it is not a stroke.\n\nStyle rules:\n- Short, natural answers. 1-2 sentences at a time unless asked to elaborate.\n- Do not list your entire history in one go. Only answer what is asked.\n- If the doctor asks an open question like 'tell me more', give a little more but stay natural.\n- You are not a medical professional. Do not use words like 'photophobia', 'aura', 'unilateral'. Say 'light hurts my eyes', 'zigzag lines', 'one side'.\n- Hidden diagnosis: migraine with aura. Never volunteer this.	t	t	Neurology	intermediate	["Neurology", "History Taking", "Emergency", "Headache"]	[]	\N	\N	\N	public	2026-04-25 17:51:14.436392	0	0	0	2026-04-25 17:51:14.436392	2026-04-25 17:51:14.436392
3	1	Shoulder Exam	physical_exam	7	1	A 30 years old female came with inability to raise her left shoulder		f	f	\N	\N	[]	[]	\N	\N	\N	public	2026-04-25 17:51:22.982023	0	1	0	2026-04-25 17:51:22.982023	2026-04-25 17:58:03.259
5	2	Peripheral Nerves Exam (Upper Limbs)	physical_exam	7	1	\N		f	f	Physiatry / PM&R	\N	[]	[]	\N	\N	\N	private	\N	0	0	0	2026-05-10 20:56:55.406717	2026-05-10 21:30:39.247
4	2	Shoulder Exam OSCE	physical_exam	7	1	A 30 years old female came with inability to raise her left shoulder		f	f	\N	\N	[]	[]	\N	\N	3	public	2026-05-09 18:16:40.766	1	0	6	2026-05-09 14:42:15.08093	2026-05-10 17:55:03.631
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sessions (sid, sess, expire) FROM stdin;
adGWXq4YI4terxJsjKW76lwa9Pc4mjJc	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-17T19:27:46.114Z","secure":true,"httpOnly":true,"path":"/","sameSite":"strict"},"passport":{"user":2}}	2026-05-17 20:03:24
HREY44rh2-goqzwz4DR32-EpXJIV3O8a	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-16T18:16:14.954Z","secure":true,"httpOnly":true,"path":"/","sameSite":"strict"},"passport":{"user":2}}	2026-05-17 22:01:29
rGFknBf1slSWss4X69_37FxBazoQh0cT	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-13T15:52:28.511Z","secure":true,"httpOnly":true,"path":"/","sameSite":"strict"}}	2026-05-13 15:52:29
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password, display_name, is_admin, bio, created_at, updated_at, email_verified_at) FROM stdin;
1	nasrww13@hotmail.com	$2b$12$E7SY3YX5cislq5YHSq7QAekTcCQpjv0GAY0fhi3L7Mzhf0LenCGhe	Nasser Alharbi	t	\N	2026-04-25 17:44:02.175908	2026-04-25 17:44:02.175908	\N
2	nasser.alharbi001@gmail.com	$2b$12$t2CLeDHOm4pk8HKJyhhM1OP2LWS29T0btVrWC4Q1NESJiKe7jCedK	Nasser Alharbi	f	A physiatry  resident in NGHA	2026-05-09 14:37:57.031936	2026-05-09 15:58:05.109	2026-05-09 14:39:12.197
\.


--
-- Name: ai_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_costs_id_seq', 307, true);


--
-- Name: collection_invites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.collection_invites_id_seq', 1, false);


--
-- Name: collection_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.collection_members_id_seq', 1, true);


--
-- Name: collection_stations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.collection_stations_id_seq', 2, true);


--
-- Name: collections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.collections_id_seq', 1, true);


--
-- Name: email_verifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_verifications_id_seq', 2, true);


--
-- Name: examiner_question_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.examiner_question_results_id_seq', 3, true);


--
-- Name: examiner_questions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.examiner_questions_id_seq', 28, true);


--
-- Name: item_media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.item_media_id_seq', 4118, true);


--
-- Name: item_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.item_results_id_seq', 837, true);


--
-- Name: items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.items_id_seq', 22817, true);


--
-- Name: mock_exam_attempts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mock_exam_attempts_id_seq', 1, false);


--
-- Name: mock_exams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mock_exams_id_seq', 1, false);


--
-- Name: password_resets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.password_resets_id_seq', 1, true);


--
-- Name: reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reports_id_seq', 1, false);


--
-- Name: sections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sections_id_seq', 1681, true);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sessions_id_seq', 8, true);


--
-- Name: stations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stations_id_seq', 5, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: ai_costs ai_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_costs
    ADD CONSTRAINT ai_costs_pkey PRIMARY KEY (id);


--
-- Name: collection_invites collection_invites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_invites
    ADD CONSTRAINT collection_invites_pkey PRIMARY KEY (id);


--
-- Name: collection_invites collection_invites_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_invites
    ADD CONSTRAINT collection_invites_token_unique UNIQUE (token);


--
-- Name: collection_members collection_members_collection_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_members
    ADD CONSTRAINT collection_members_collection_id_user_id_unique UNIQUE (collection_id, user_id);


--
-- Name: collection_members collection_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_members
    ADD CONSTRAINT collection_members_pkey PRIMARY KEY (id);


--
-- Name: collection_stars collection_stars_user_id_collection_id_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_stars
    ADD CONSTRAINT collection_stars_user_id_collection_id_pk PRIMARY KEY (user_id, collection_id);


--
-- Name: collection_stations collection_stations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_stations
    ADD CONSTRAINT collection_stations_pkey PRIMARY KEY (id);


--
-- Name: collections collections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_pkey PRIMARY KEY (id);


--
-- Name: email_verifications email_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_verifications
    ADD CONSTRAINT email_verifications_pkey PRIMARY KEY (id);


--
-- Name: email_verifications email_verifications_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_verifications
    ADD CONSTRAINT email_verifications_token_key UNIQUE (token);


--
-- Name: examiner_question_results examiner_question_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.examiner_question_results
    ADD CONSTRAINT examiner_question_results_pkey PRIMARY KEY (id);


--
-- Name: examiner_questions examiner_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.examiner_questions
    ADD CONSTRAINT examiner_questions_pkey PRIMARY KEY (id);


--
-- Name: item_media item_media_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_media
    ADD CONSTRAINT item_media_pkey PRIMARY KEY (id);


--
-- Name: item_results item_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_results
    ADD CONSTRAINT item_results_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: mock_exam_attempts mock_exam_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mock_exam_attempts
    ADD CONSTRAINT mock_exam_attempts_pkey PRIMARY KEY (id);


--
-- Name: mock_exams mock_exams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mock_exams
    ADD CONSTRAINT mock_exams_pkey PRIMARY KEY (id);


--
-- Name: password_resets password_resets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_resets
    ADD CONSTRAINT password_resets_pkey PRIMARY KEY (id);


--
-- Name: password_resets password_resets_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_resets
    ADD CONSTRAINT password_resets_token_unique UNIQUE (token);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: sections sections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT sections_pkey PRIMARY KEY (id);


--
-- Name: user_sessions session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: station_stars station_stars_user_id_station_id_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.station_stars
    ADD CONSTRAINT station_stars_user_id_station_id_pk PRIMARY KEY (user_id, station_id);


--
-- Name: stations stations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stations
    ADD CONSTRAINT stations_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_session_expire" ON public.user_sessions USING btree (expire);


--
-- Name: email_verifications_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_verifications_expires_at_idx ON public.email_verifications USING btree (expires_at);


--
-- Name: email_verifications_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_verifications_user_id_idx ON public.email_verifications USING btree (user_id);


--
-- Name: idx_collection_members_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_collection_members_user ON public.collection_members USING btree (user_id);


--
-- Name: collection_invites collection_invites_accepted_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_invites
    ADD CONSTRAINT collection_invites_accepted_by_users_id_fk FOREIGN KEY (accepted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: collection_invites collection_invites_collection_id_collections_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_invites
    ADD CONSTRAINT collection_invites_collection_id_collections_id_fk FOREIGN KEY (collection_id) REFERENCES public.collections(id) ON DELETE CASCADE;


--
-- Name: collection_invites collection_invites_invited_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_invites
    ADD CONSTRAINT collection_invites_invited_by_users_id_fk FOREIGN KEY (invited_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: collection_members collection_members_collection_id_collections_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_members
    ADD CONSTRAINT collection_members_collection_id_collections_id_fk FOREIGN KEY (collection_id) REFERENCES public.collections(id) ON DELETE CASCADE;


--
-- Name: collection_members collection_members_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_members
    ADD CONSTRAINT collection_members_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: collection_stars collection_stars_collection_id_collections_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_stars
    ADD CONSTRAINT collection_stars_collection_id_collections_id_fk FOREIGN KEY (collection_id) REFERENCES public.collections(id) ON DELETE CASCADE;


--
-- Name: collection_stars collection_stars_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_stars
    ADD CONSTRAINT collection_stars_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: collection_stations collection_stations_collection_id_collections_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_stations
    ADD CONSTRAINT collection_stations_collection_id_collections_id_fk FOREIGN KEY (collection_id) REFERENCES public.collections(id) ON DELETE CASCADE;


--
-- Name: collection_stations collection_stations_station_id_stations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_stations
    ADD CONSTRAINT collection_stations_station_id_stations_id_fk FOREIGN KEY (station_id) REFERENCES public.stations(id) ON DELETE CASCADE;


--
-- Name: collections collections_fork_of_collections_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_fork_of_collections_id_fk FOREIGN KEY (fork_of) REFERENCES public.collections(id) ON DELETE SET NULL;


--
-- Name: collections collections_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: email_verifications email_verifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_verifications
    ADD CONSTRAINT email_verifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: examiner_question_results examiner_question_results_question_id_examiner_questions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.examiner_question_results
    ADD CONSTRAINT examiner_question_results_question_id_examiner_questions_id_fk FOREIGN KEY (question_id) REFERENCES public.examiner_questions(id) ON DELETE CASCADE;


--
-- Name: examiner_question_results examiner_question_results_session_id_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.examiner_question_results
    ADD CONSTRAINT examiner_question_results_session_id_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: examiner_questions examiner_questions_station_id_stations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.examiner_questions
    ADD CONSTRAINT examiner_questions_station_id_stations_id_fk FOREIGN KEY (station_id) REFERENCES public.stations(id) ON DELETE CASCADE;


--
-- Name: item_media item_media_item_id_items_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_media
    ADD CONSTRAINT item_media_item_id_items_id_fk FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: item_results item_results_item_id_items_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_results
    ADD CONSTRAINT item_results_item_id_items_id_fk FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: item_results item_results_session_id_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_results
    ADD CONSTRAINT item_results_session_id_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: items items_section_id_sections_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_section_id_sections_id_fk FOREIGN KEY (section_id) REFERENCES public.sections(id) ON DELETE CASCADE;


--
-- Name: mock_exam_attempts mock_exam_attempts_mock_exam_id_mock_exams_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mock_exam_attempts
    ADD CONSTRAINT mock_exam_attempts_mock_exam_id_mock_exams_id_fk FOREIGN KEY (mock_exam_id) REFERENCES public.mock_exams(id) ON DELETE CASCADE;


--
-- Name: mock_exam_attempts mock_exam_attempts_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mock_exam_attempts
    ADD CONSTRAINT mock_exam_attempts_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mock_exams mock_exams_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mock_exams
    ADD CONSTRAINT mock_exams_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: password_resets password_resets_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_resets
    ADD CONSTRAINT password_resets_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reports reports_reporter_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_reporter_id_users_id_fk FOREIGN KEY (reporter_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: reports reports_reviewed_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_reviewed_by_users_id_fk FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: sections sections_station_id_stations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT sections_station_id_stations_id_fk FOREIGN KEY (station_id) REFERENCES public.stations(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_mock_exam_attempt_id_mock_exam_attempts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_mock_exam_attempt_id_mock_exam_attempts_id_fk FOREIGN KEY (mock_exam_attempt_id) REFERENCES public.mock_exam_attempts(id) ON DELETE SET NULL;


--
-- Name: sessions sessions_mock_exam_id_mock_exams_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_mock_exam_id_mock_exams_id_fk FOREIGN KEY (mock_exam_id) REFERENCES public.mock_exams(id) ON DELETE SET NULL;


--
-- Name: sessions sessions_station_id_stations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_station_id_stations_id_fk FOREIGN KEY (station_id) REFERENCES public.stations(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: station_stars station_stars_station_id_stations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.station_stars
    ADD CONSTRAINT station_stars_station_id_stations_id_fk FOREIGN KEY (station_id) REFERENCES public.stations(id) ON DELETE CASCADE;


--
-- Name: station_stars station_stars_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.station_stars
    ADD CONSTRAINT station_stars_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: stations stations_fork_of_stations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stations
    ADD CONSTRAINT stations_fork_of_stations_id_fk FOREIGN KEY (fork_of) REFERENCES public.stations(id) ON DELETE SET NULL;


--
-- Name: stations stations_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stations
    ADD CONSTRAINT stations_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 3mMS94yvCPvCBblZpS6DY21q81qiUOxSSx8JaLAy2meejjP07QYufr4n97uVg97

